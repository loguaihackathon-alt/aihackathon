import os
import time
from datetime import datetime

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from models import init_db, SessionLocal, UseCase, AgentRun
from agents import run_pipeline
from seed_db import seed
from auth import authenticate, filter_use_cases, TAB_LABELS, PERSONAS

load_dotenv()
init_db()
seed()

# ── Page config ──────────────────────────────────────────
st.set_page_config(
    page_title="AI Opportunity Prioritization",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Shared CSS ───────────────────────────────────────────
st.markdown("""
<style>
  .main .block-container { padding-top: 1.2rem; }
  .kpi-box { background:#1A1612; border-radius:10px; padding:1.2rem 1rem;
             text-align:center; color:#fff; }
  .kpi-num { font-size:2.2rem; font-weight:700; line-height:1; }
  .kpi-lbl { font-size:0.65rem; text-transform:uppercase; letter-spacing:.08em;
             color:rgba(255,255,255,.5); margin-top:4px; }
  .dec-pursue  { background:#C0DD97; color:#27500A; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-validate{ background:#B5D4F4; color:#0C447C; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-defer   { background:#FAC775; color:#633806; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-pass    { background:#D3D1C7; color:#444441; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .matrix-cell { border-radius:10px; padding:14px; min-height:130px; }
  .q1 { background:linear-gradient(135deg,#EAF3DE,#F0F8E8); }
  .q2 { background:linear-gradient(135deg,#E6F1FB,#EFF5FD); }
  .q3 { background:linear-gradient(135deg,#FAEEDA,#FDF4E7); }
  .q4 { background:linear-gradient(135deg,#F1EFE8,#F7F5F0); }
  .chip { display:inline-block; background:#fff; border:1px solid rgba(0,0,0,.1);
          border-radius:6px; padding:3px 8px; font-size:.75rem; margin:2px; }

  /* Login card */
  .login-card { background:#fff; border-radius:16px; padding:2.5rem 2rem;
                box-shadow:0 8px 40px rgba(0,0,0,0.10); max-width:440px; margin:3rem auto; }
  .login-title { font-size:1.5rem; font-weight:700; color:#1A1612; margin-bottom:.25rem; }
  .login-sub   { font-size:.85rem; color:#888; margin-bottom:1.5rem; }
  .persona-pill { display:inline-flex; align-items:center; gap:6px;
                  background:#F7F5F0; border:1px solid #E0DDD6;
                  border-radius:8px; padding:6px 12px; margin:4px;
                  font-size:.8rem; cursor:default; }
  .role-admin   { border-left:4px solid #1A1612; }
  .role-executive{ border-left:4px solid #185FA5; }
  .role-manager { border-left:4px solid #854F0B; }

  /* Top bar */
  .topbar { display:flex; align-items:center; justify-content:space-between;
            padding:.5rem 0 1rem; border-bottom:1px solid #E8E4DC; margin-bottom:1rem; }
  .topbar-left { font-size:1.1rem; font-weight:600; color:#1A1612; }
  .topbar-right{ font-size:.8rem; color:#888; display:flex; align-items:center; gap:12px; }
  .access-badge{ background:#F7F5F0; border:1px solid #E0DDD6; border-radius:20px;
                 padding:3px 12px; font-size:.75rem; font-weight:500; }
</style>
""", unsafe_allow_html=True)


# ════════════════════════════════════════════════════════
# SESSION STATE
# ════════════════════════════════════════════════════════
if "persona" not in st.session_state:
    st.session_state.persona = None
if "login_error" not in st.session_state:
    st.session_state.login_error = ""


# ════════════════════════════════════════════════════════
# DB HELPERS
# ════════════════════════════════════════════════════════
def get_all_use_cases() -> list[dict]:
    db = SessionLocal()
    try:
        rows = db.query(UseCase).all()
        return [_uc_dict(u) for u in sorted(
            rows, key=lambda u: u.business_value + u.feasibility + u.strategic_fit, reverse=True
        )]
    finally:
        db.close()


def get_kpis(use_cases: list[dict]) -> dict:
    return {
        "total":          len(use_cases),
        "pursue":         sum(1 for u in use_cases if u["decision"] == "pursue"),
        "validate":       sum(1 for u in use_cases if u["decision"] == "validate"),
        "defer":          sum(1 for u in use_cases if u["decision"] == "defer"),
        "pass_count":     sum(1 for u in use_cases if u["decision"] == "pass"),
        "total_impact_m": round(sum(u["impact_raw"] for u in use_cases), 1),
    }


def add_use_case(payload: dict):
    db = SessionLocal()
    try:
        db.add(UseCase(**payload))
        db.commit()
    finally:
        db.close()


def save_agent_runs(uc_id: int, result: dict, elapsed_ms: int):
    db = SessionLocal()
    try:
        now = datetime.utcnow().isoformat()
        llm_model = os.getenv("GENAI_LLM_MODEL", "")
        for key in ("analyst_output", "scorer_output", "prioritizer_output"):
            db.add(AgentRun(
                use_case_id=uc_id, agent_name=key.replace("_output", ""),
                output=result[key], llm_model=llm_model,
                elapsed_ms=elapsed_ms, created_at=now,
            ))
        db.commit()
    finally:
        db.close()


def get_agent_runs(uc_id: int) -> list[dict]:
    db = SessionLocal()
    try:
        runs = db.query(AgentRun).filter(AgentRun.use_case_id == uc_id).order_by(AgentRun.id.desc()).all()
        return [{"agent": r.agent_name, "output": r.output,
                 "llm_model": r.llm_model, "elapsed_ms": r.elapsed_ms,
                 "created_at": r.created_at} for r in runs]
    finally:
        db.close()


def _uc_dict(u: UseCase) -> dict:
    return {
        "id": u.id, "name": u.name, "function": u.function,
        "decision": u.decision,
        "business_value": u.business_value, "feasibility": u.feasibility,
        "strategic_fit": u.strategic_fit,   "complexity": u.complexity,
        "total_score": u.business_value + u.feasibility + u.strategic_fit,
        "impact": u.impact, "impact_raw": u.impact_raw or 0,
        "problem": u.problem,  "benefit": u.benefit, "users": u.users,
        "inputs": u.inputs,    "risk": u.risk, "complexity_note": u.complexity_note,
    }


# ── UI helpers ───────────────────────────────────────────
def decision_badge(d: str) -> str:
    cls   = {"pursue":"dec-pursue","validate":"dec-validate",
             "defer":"dec-defer","pass":"dec-pass"}.get(d,"dec-pass")
    label = {"pursue":"Pursue Now","validate":"Validate",
             "defer":"Defer","pass":"Pass"}.get(d,d)
    return f'<span class="{cls}">{label}</span>'


def score_bar(val: int, max_val: int = 5, color: str = "#1A1612") -> str:
    pct = int(val / max_val * 100)
    return (f'<div style="display:flex;align-items:center;gap:6px">'
            f'<div style="flex:1;height:5px;background:#EEE;border-radius:3px;overflow:hidden">'
            f'<div style="width:{pct}%;height:100%;background:{color};border-radius:3px"></div></div>'
            f'<span style="font-size:.75rem;color:#666;min-width:24px">{val}/5</span></div>')


# ════════════════════════════════════════════════════════
# LOGIN SCREEN
# ════════════════════════════════════════════════════════
def render_login():
    # Build persona hint table
    hints = []
    for uname, p in PERSONAS.items():
        hints.append(
            f'<div class="persona-pill role-{p["role"]}">'
            f'{p["avatar"]} <strong>{p["name"]}</strong>'
            f'<span style="color:#aaa;margin-left:4px">·</span>'
            f'<span style="color:#888">{uname} / {p["password"]}</span></div>'
        )

    st.markdown(f"""
    <div class="login-card">
      <div class="login-title">🤖 AI Opportunity Intelligence</div>
      <div class="login-sub">Enterprise Prioritization Platform · June 2025</div>
    </div>
    """, unsafe_allow_html=True)

    # Centre the form
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        st.markdown("#### Sign in to your workspace")
        with st.form("login_form"):
            username = st.text_input("Username", placeholder="e.g. ceo")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Sign In →", type="primary", use_container_width=True)

        if st.session_state.login_error:
            st.error(st.session_state.login_error)

        if submitted:
            result = authenticate(username, password)
            if result:
                st.session_state.persona = result
                st.session_state.login_error = ""
                st.rerun()
            else:
                st.session_state.login_error = "Invalid username or password."
                st.rerun()

        st.divider()
        st.markdown("**Demo credentials**")
        st.markdown(
            "<div style='display:flex;flex-wrap:wrap;gap:4px'>" +
            "".join(hints) + "</div>",
            unsafe_allow_html=True,
        )
        st.caption("👑 Admin · 🔵 Executive · 🟤 Manager")


# ════════════════════════════════════════════════════════
# MAIN APP (authenticated)
# ════════════════════════════════════════════════════════
def render_app(persona: dict):
    # ── Top bar ──────────────────────────────────────────
    all_uc = get_all_use_cases()
    visible_uc = filter_use_cases(all_uc, persona)

    role_color = {"admin": "#1A1612", "executive": "#185FA5", "manager": "#854F0B"}.get(persona["role"], "#888")
    scope_label = "All Functions" if not persona["functions"] else ", ".join(persona["functions"])

    st.markdown(
        f'<div class="topbar">'
        f'<div class="topbar-left">{persona["avatar"]} {persona["title"]} Dashboard</div>'
        f'<div class="topbar-right">'
        f'<span class="access-badge" style="border-left:3px solid {role_color}">'
        f'{persona["role"].capitalize()} · {scope_label}</span>'
        f'</div></div>',
        unsafe_allow_html=True,
    )

    # Logout in sidebar
    with st.sidebar:
        st.markdown(f"### {persona['avatar']} {persona['name']}")
        st.caption(persona["title"])
        st.caption(f"Role: **{persona['role'].capitalize()}**")
        if persona["functions"]:
            st.caption("**Your functions:**")
            for f in persona["functions"]:
                st.caption(f"  • {f}")
        else:
            st.caption("Access: **All Functions**")
        st.divider()
        if st.button("🚪 Sign Out", use_container_width=True):
            st.session_state.persona = None
            st.rerun()

    # ── KPI Strip ────────────────────────────────────────
    kpis = get_kpis(visible_uc)
    st.markdown("## 🤖 AI Opportunity Backlog & Prioritization Matrix")
    st.caption(f"Enterprise-wide · June 2025  |  Showing **{len(visible_uc)}** use case(s) for {persona['title']}")

    c1, c2, c3, c4, c5 = st.columns(5)
    for col, num, lbl, color in [
        (c1, kpis["total"],                   "Use Cases",         "#fff"),
        (c2, kpis["pursue"],                  "Pursue Now",        "#97C459"),
        (c3, kpis["validate"],                "Validate",          "#85B7EB"),
        (c4, kpis["defer"],                   "Defer",             "#FAC775"),
        (c5, f"~${kpis['total_impact_m']}M",  "Est. Annual Impact","#9FE1CB"),
    ]:
        col.markdown(
            f'<div class="kpi-box"><div class="kpi-num" style="color:{color}">{num}</div>'
            f'<div class="kpi-lbl">{lbl}</div></div>',
            unsafe_allow_html=True,
        )

    st.divider()

    # ── Build visible tabs ────────────────────────────────
    allowed_tab_indices = persona["tabs"]
    tab_labels = [TAB_LABELS[i] for i in allowed_tab_indices]
    tabs = st.tabs(tab_labels)

    def get_tab(logical_idx: int):
        """Return the st.tab context for a logical tab index, or None if not allowed."""
        if logical_idx in allowed_tab_indices:
            return tabs[allowed_tab_indices.index(logical_idx)]
        return None

    # ════════════════════════════════════════════════════
    # TAB 0 — MATRIX
    # ════════════════════════════════════════════════════
    t = get_tab(0)
    if t:
        with t:
            st.markdown("### Prioritization Matrix — Business Value vs Implementation Complexity")
            if not visible_uc:
                st.info("No use cases available for your function scope.")
            else:
                def chips_for(decision: str) -> str:
                    return " ".join(
                        f'<span class="chip">● {u["name"]}</span>'
                        for u in visible_uc if u["decision"] == decision
                    )

                _, col_low, col_high = st.columns([0.5, 5, 5])
                col_low.markdown('<div style="text-align:center;font-size:.75rem;font-weight:600;color:#888;'
                                 'text-transform:uppercase;letter-spacing:.08em">↑ Lower Complexity</div>',
                                 unsafe_allow_html=True)
                col_high.markdown('<div style="text-align:center;font-size:.75rem;font-weight:600;color:#888;'
                                  'text-transform:uppercase;letter-spacing:.08em">↑ Higher Complexity</div>',
                                  unsafe_allow_html=True)

                dec_label  = {"pursue":"Pursue Now","validate":"Validate","defer":"Defer","pass":"Pass"}
                cell_title = {"pursue":"Quick Wins","validate":"Strategic Bets",
                              "defer":"Monitor & Re-evaluate","pass":"Low Priority"}
                badge_cls  = {"pursue":"dec-pursue","validate":"dec-validate",
                              "defer":"dec-defer","pass":"dec-pass"}

                for row_lbl, dec1, cls1, dec2, cls2 in [
                    ("Higher Value", "pursue",  "q1", "validate", "q2"),
                    ("Lower Value",  "defer",   "q3", "pass",     "q4"),
                ]:
                    lbl_col, left_col, right_col = st.columns([0.5, 5, 5])
                    lbl_col.markdown(
                        f'<div style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:.7rem;'
                        f'font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.08em;'
                        f'height:140px;display:flex;align-items:center">{row_lbl}</div>',
                        unsafe_allow_html=True,
                    )
                    for col, dec, cell_cls in [(left_col, dec1, cls1), (right_col, dec2, cls2)]:
                        col.markdown(
                            f'<div class="matrix-cell {cell_cls}">'
                            f'<span class="{badge_cls[dec]}">{dec_label[dec]}</span>'
                            f'<div style="font-size:.7rem;color:#888;text-transform:uppercase;'
                            f'letter-spacing:.08em;margin:8px 0 6px">{cell_title[dec]}</div>'
                            f'{chips_for(dec)}</div>',
                            unsafe_allow_html=True,
                        )

    # ════════════════════════════════════════════════════
    # TAB 1 — BACKLOG
    # ════════════════════════════════════════════════════
    t = get_tab(1)
    if t:
        with t:
            st.markdown("### Opportunity Backlog")
            fcol1, fcol2 = st.columns([3, 1])
            with fcol1:
                filter_dec = st.radio("Filter", ["All", "pursue", "validate", "defer", "pass"],
                                      horizontal=True, label_visibility="collapsed")
            with fcol2:
                sort_by = st.selectbox("Sort by",
                                       ["total_score", "business_value", "feasibility", "impact_raw"],
                                       label_visibility="collapsed")

            uc_list = [u for u in visible_uc if filter_dec == "All" or u["decision"] == filter_dec]
            uc_list = sorted(uc_list, key=lambda x: x.get(sort_by, 0), reverse=True)

            if not uc_list:
                st.info("No use cases match this filter for your function scope.")
            else:
                icon = {"pursue": "🟢", "validate": "🔵", "defer": "🟡", "pass": "⚫"}
                for uc in uc_list:
                    with st.expander(f"{icon.get(uc['decision'],'⚪')}  {uc['name']}  —  {uc['function']}"):
                        left, right = st.columns(2)
                        with left:
                            st.markdown(f"**Decision:** {decision_badge(uc['decision'])}", unsafe_allow_html=True)
                            for lbl, val, color in [
                                ("Business Value", uc["business_value"], "#639922"),
                                ("Feasibility",    uc["feasibility"],    "#185FA5"),
                                ("Strategic Fit",  uc["strategic_fit"],  "#534AB7"),
                            ]:
                                st.markdown(f"**{lbl}**")
                                st.markdown(score_bar(val, color=color), unsafe_allow_html=True)
                            st.markdown(f"**Composite Score:** `{uc['total_score']}/15`")
                            st.markdown(f"**Est. Annual Impact:** `{uc['impact']}`")
                        with right:
                            for lbl, val in [
                                ("Problem",     uc["problem"]),
                                ("Benefits",    uc["benefit"]),
                                ("Users",       uc["users"]),
                                ("Data Inputs", uc["inputs"]),
                                ("Risks",       uc["risk"]),
                                ("Complexity",  uc["complexity_note"]),
                            ]:
                                st.markdown(f"**{lbl}:** {val}")

    # ════════════════════════════════════════════════════
    # TAB 2 — SCORING
    # ════════════════════════════════════════════════════
    t = get_tab(2)
    if t:
        with t:
            st.markdown("### Scoring Summary — Ranked by Composite Score (max 15)")
            sorted_uc = sorted(visible_uc, key=lambda x: x["total_score"], reverse=True)
            df = pd.DataFrame([{
                "Rank":           i + 1,
                "Use Case":       u["name"],
                "Function":       u["function"],
                "Decision":       u["decision"].capitalize(),
                "Business Value": u["business_value"],
                "Feasibility":    u["feasibility"],
                "Strategic Fit":  u["strategic_fit"],
                "Total":          u["total_score"],
                "Est. Impact":    u["impact"],
            } for i, u in enumerate(sorted_uc)])

            st.dataframe(df, use_container_width=True, hide_index=True, column_config={
                "Total":          st.column_config.ProgressColumn("Total",          min_value=0, max_value=15, format="%d"),
                "Business Value": st.column_config.ProgressColumn("Business Value", min_value=0, max_value=5,  format="%d"),
                "Feasibility":    st.column_config.ProgressColumn("Feasibility",    min_value=0, max_value=5,  format="%d"),
                "Strategic Fit":  st.column_config.ProgressColumn("Strategic Fit",  min_value=0, max_value=5,  format="%d"),
            })

    # ════════════════════════════════════════════════════
    # TAB 3 — ROADMAP
    # ════════════════════════════════════════════════════
    t = get_tab(3)
    if t:
        with t:
            st.markdown("### Transformation Roadmap — Phased Delivery")

            # Filter roadmap items to only show functions this persona owns
            roadmap = {
                "Phase 1 — Foundation": {
                    "caption": "0 – 3 months · ~$3.4M/yr impact",
                    "color": "🟢",
                    "items": [
                        ("IT Operations",       "Deploy AI Incident Trend Analyser — target 35% MTTR reduction"),
                        ("PMO",                 "Launch Auto Project Status Reports integrated with PPM toolchain"),
                        ("Governance / PMO",    "Pilot AI Governance Action Tracker across 3 steering forums"),
                        ("Service Desk",        "Index existing KB for Intelligent Support Search — rollout to L1/L2"),
                        ("IT Architecture",     "Deploy AI-Driven Infrastructure Capacity Planning on cloud billing data"),
                        ("Programme Management","Launch AI Portfolio Health Scorecard across top-10 programmes"),
                        ("AI Strategy",         "Automate Enterprise AI Maturity Assessment across all 12 BUs"),
                        ("AI Strategy",         "Activate AI Use Case ROI Tracker for Pursue-tier initiatives"),
                    ],
                },
                "Phase 2 — Scale & Validate": {
                    "caption": "3 – 9 months · ~$6.6M/yr impact",
                    "color": "🔵",
                    "items": [
                        ("Delivery / PMO",        "Ingest 3 years of historical project data for Effort Forecasting AI"),
                        ("Architecture",           "Pilot Architecture Pattern Recommender with 2 squads"),
                        ("Legal / Procurement",    "Legal & procurement validation for Contract Risk Analyser"),
                        ("Pre-Sales / Bid Mgmt",   "Integrate Intelligent RFP Engine with bid management workflow"),
                        ("IT Architecture",        "Validate Architecture Decision Record Intelligence with 3 architecture guilds"),
                        ("IT Architecture",        "Pilot AI Security Vulnerability Pattern Detector on IaC pipelines"),
                        ("Programme Management",   "Deploy Predictive Project Risk Early Warning across 20+ active programmes"),
                        ("AI Strategy",            "Run AI Talent & Skill Gap Intelligence to inform L&D investment"),
                    ],
                },
                "Phase 3 — Expand & Embed": {
                    "caption": "9 – 18 months · Platform investment cycle",
                    "color": "🟣",
                    "items": [
                        ("", "Reassess deferred use cases against real performance & data quality"),
                        ("", "Build cross-function shared AI platform for model reuse"),
                        ("", "Establish enterprise AI ethics, audit, and risk governance framework"),
                        ("", "Conduct ROI review and open next opportunity identification cycle"),
                        ("", "Embed Automated Lessons Learned KB across all project closure workflows"),
                    ],
                },
            }

            p1, p2, p3 = st.columns(3)
            for col, (phase_name, phase) in zip([p1, p2, p3], roadmap.items()):
                with col:
                    st.markdown(f"#### {phase['color']} {phase_name}")
                    st.caption(phase["caption"])
                    for fn, item in phase["items"]:
                        # Show all items for admin; for others show only their functions
                        # Phase 3 items have no function tag — show to all
                        if not persona["functions"] or not fn or fn in persona["functions"]:
                            st.markdown(f"- {item}")

    # ════════════════════════════════════════════════════
    # TAB 4 — AI ANALYSIS
    # ════════════════════════════════════════════════════
    t = get_tab(4)
    if t:
        with t:
            st.markdown("### 🤖 Multi-Agent AI Analysis")
            if not persona["can_run_agent"]:
                st.warning("Your role does not have access to run AI agent pipelines.")
            elif not visible_uc:
                st.info("No use cases available for your function scope.")
            else:
                st.info("Select a use case to run the **Analyst → Scorer → Prioritizer** LangGraph pipeline.")
                uc_map = {u["name"]: u for u in visible_uc}
                selected_name = st.selectbox("Select Use Case", list(uc_map.keys()))
                selected_uc   = uc_map[selected_name]

                if st.button("▶ Run Agent Pipeline", type="primary"):
                    with st.spinner("Running 3-agent pipeline: Analyst → Scorer → Prioritizer…"):
                        t0 = time.time()
                        try:
                            result = run_pipeline(selected_uc)
                            elapsed_ms = int((time.time() - t0) * 1000)
                            save_agent_runs(selected_uc["id"], result, elapsed_ms)
                            st.success(f"Pipeline completed in {elapsed_ms / 1000:.1f}s  |  Model: {os.getenv('GENAI_LLM_MODEL','')}")
                            with st.expander("🔍 Analyst Agent", expanded=True):
                                st.markdown(result["analyst_output"])
                            with st.expander("📊 Scorer Agent", expanded=True):
                                st.markdown(result["scorer_output"])
                            with st.expander("🎯 Prioritizer Agent", expanded=True):
                                st.markdown(result["prioritizer_output"])
                        except Exception as e:
                            st.error(f"Pipeline error: {e}")

                st.divider()
                st.markdown("**Previous Agent Runs**")
                runs = get_agent_runs(selected_uc["id"])
                if runs:
                    for run in runs[:6]:
                        label = (f"{run['agent'].capitalize()} Agent — "
                                 f"{(run['created_at'] or '')[:19]}  |  "
                                 f"model: {run['llm_model'] or '—'}  |  "
                                 f"{run['elapsed_ms'] or 0}ms")
                        with st.expander(label):
                            st.markdown(run["output"] or "")
                else:
                    st.caption("No previous runs for this use case.")

    # ════════════════════════════════════════════════════
    # TAB 5 — ADD USE CASE
    # ════════════════════════════════════════════════════
    t = get_tab(5)
    if t:
        with t:
            st.markdown("### ➕ Add New AI Opportunity")
            if not persona["can_add"]:
                st.warning("Your role does not have permission to add use cases.")
            else:
                # Pre-select function scope for non-admins
                default_fns = persona["functions"] if persona["functions"] else []
                with st.form("add_uc_form"):
                    name     = st.text_input("Use Case Name *")
                    function = st.text_input("Business Function *",
                                             value=default_fns[0] if len(default_fns) == 1 else "")
                    decision = st.selectbox("Decision", ["pursue", "validate", "defer", "pass"])
                    c1, c2, c3 = st.columns(3)
                    bv = c1.slider("Business Value (1–5)", 1, 5, 3)
                    fs = c2.slider("Feasibility (1–5)",    1, 5, 3)
                    sf = c3.slider("Strategic Fit (1–5)",  1, 5, 3)
                    complexity      = st.slider("Complexity (1–3)", 1, 3, 2)
                    impact          = st.text_input("Est. Annual Impact", "TBD")
                    impact_raw      = st.number_input("Impact Raw ($M)", min_value=0.0, step=0.1, value=0.0)
                    problem         = st.text_area("Business Problem")
                    benefit         = st.text_area("Expected Benefits")
                    users           = st.text_input("Target Users")
                    inputs          = st.text_input("Data / Process Inputs")
                    risk            = st.text_area("Key Risks & Dependencies")
                    complexity_note = st.text_input("Complexity Note")
                    submitted       = st.form_submit_button("Add Use Case", type="primary")

                if submitted:
                    if not name or not function:
                        st.warning("Name and Function are required.")
                    else:
                        add_use_case(dict(
                            name=name, function=function, decision=decision,
                            business_value=bv, feasibility=fs, strategic_fit=sf,
                            complexity=complexity, impact=impact, impact_raw=impact_raw,
                            problem=problem, benefit=benefit, users=users,
                            inputs=inputs, risk=risk, complexity_note=complexity_note,
                        ))
                        st.success(f"✅ Use case '{name}' added successfully!")
                        st.rerun()


# ════════════════════════════════════════════════════════
# ROUTER
# ════════════════════════════════════════════════════════
if st.session_state.persona is None:
    render_login()
else:
    render_app(st.session_state.persona)
