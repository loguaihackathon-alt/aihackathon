from models import init_db, SessionLocal, UseCase

SEED_DATA = [
    dict(id=1, name="AI-Assisted Incident Trend Analysis", function="IT Operations", decision="pursue",
         business_value=5, feasibility=5, strategic_fit=5, complexity=1, impact="~$1.2M/yr", impact_raw=1.2,
         problem="Manual triage of recurring incidents consumes L2/L3 engineer hours and delays MTTR significantly across regions.",
         benefit="30–40% reduction in MTTR; proactive pattern identification before SLA breaches; reduced escalation rate.",
         users="IT Ops managers, NOC teams, Service Desk leads",
         inputs="ITSM ticket data (ServiceNow/Jira), monitoring alerts, CMDB asset register",
         risk="Data quality in legacy ITSM; model drift if infrastructure topology changes significantly.",
         complexity_note="Low — existing ITSM APIs are mature; NLP summarisation is a well-proven pattern"),

    dict(id=2, name="Automated Project Status Summarisation", function="PMO", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=1, impact="~$0.8M/yr", impact_raw=0.8,
         problem="PMs spend 2–4 hrs/week manually compiling status reports across disparate tools — error-prone and inconsistent.",
         benefit="80% time saving on status reporting; consistent real-time dashboards for leadership; improved escalation speed.",
         users="Project managers, Programme directors, Executive sponsors, Portfolio office",
         inputs="Jira, MS Project, Confluence, financial trackers, risk registers",
         risk="Tool integration complexity; governance over AI-generated narratives; hallucination on financial data.",
         complexity_note="Low — API integrations are mature; NLP summarisation with structured data is proven"),

    dict(id=3, name="AI Governance Action Tracker", function="Governance / PMO", decision="pursue",
         business_value=4, feasibility=5, strategic_fit=5, complexity=1, impact="~$0.5M/yr", impact_raw=0.5,
         problem="Action items from governance forums tracked manually in spreadsheets — missed deadlines, no accountability trail.",
         benefit="Full action closure visibility; automated nudges and escalations; real-time status to leadership.",
         users="Governance leads, Steering committee members, PMO, Risk function",
         inputs="Meeting transcripts, email threads, action log spreadsheets, calendar integrations",
         risk="Stakeholder adoption; accuracy of meeting transcript AI; integration with existing tools.",
         complexity_note="Low — can be built on existing collaboration platforms (Teams, Outlook, SharePoint)"),

    dict(id=4, name="Intelligent Knowledge Search (Support)", function="Service Desk", decision="pursue",
         business_value=4, feasibility=5, strategic_fit=4, complexity=1, impact="~$0.9M/yr", impact_raw=0.9,
         problem="Support agents spend ~25% of call time searching fragmented knowledge bases, leading to slow resolution and low FCR.",
         benefit="20–30% faster resolution; improved first-contact resolution rate; reduced agent training time by 40%.",
         users="L1/L2 support agents, Service Desk managers, Quality assurance leads",
         inputs="KB articles, Confluence, SharePoint, resolved ticket corpus, SOP documents",
         risk="Knowledge base freshness and quality; change management for agents; indexing cost for large corpora.",
         complexity_note="Low-Medium — RAG-based semantic search architecture; well-proven, fast to deploy"),

    dict(id=5, name="Intelligent Effort & Capacity Forecasting", function="Delivery / PMO", decision="validate",
         business_value=5, feasibility=3, strategic_fit=5, complexity=2, impact="~$2.1M/yr", impact_raw=2.1,
         problem="Project estimates rely on individual judgement, causing systematic over/under-runs of 20–35% that damage margins.",
         benefit="Reduce estimation error by up to 50%; improve resource utilisation; strengthen commercial negotiations.",
         users="Delivery leads, Resource managers, Finance controllers, Client commercial teams",
         inputs="Historical project actuals (3+ yrs), JIRA timesheets, HR capacity data, contract terms",
         risk="Data completeness for historical actuals; model explainability for client-facing estimates; change adoption.",
         complexity_note="Medium — requires clean historical data ingestion; regression/ML modelling; human validation layer"),

    dict(id=6, name="Architecture Pattern Recommender", function="Architecture", decision="validate",
         business_value=5, feasibility=3, strategic_fit=5, complexity=2, impact="~$1.5M/yr", impact_raw=1.5,
         problem="Solution architects repeatedly solve similar design challenges from scratch — slowing pre-sales and delivery phases.",
         benefit="40% faster architecture design; proven pattern reuse; reduced technical debt across delivery portfolio.",
         users="Solution architects, Principal engineers, Pre-sales teams, Tech leads",
         inputs="Internal design docs, architecture decision records, cloud provider pattern libraries, RFP history",
         risk="Proprietary data security; risk of over-standardisation stifling innovation; corpus curation cost.",
         complexity_note="Medium — requires curated architecture corpus; LLM fine-tuning or RAG with domain experts"),

    dict(id=7, name="Contract Risk & Obligation Analyser", function="Legal / Procurement", decision="validate",
         business_value=5, feasibility=3, strategic_fit=4, complexity=3, impact="~$1.8M/yr", impact_raw=1.8,
         problem="Legal teams manually review hundreds of pages of contracts, risking missed obligations and unpriced commercial risk.",
         benefit="90% reduction in manual review time; earlier risk identification; improved compliance and obligation tracking.",
         users="Legal counsel, Procurement managers, Contract managers, Finance",
         inputs="Contract PDFs, obligation registers, regulatory checklists, precedent libraries",
         risk="Regulatory risk of AI-generated legal interpretation; hallucination on nuanced clauses; PII handling.",
         complexity_note="Medium-High — legal domain sensitivity; human validation workflow mandatory; fine-tuning required"),

    dict(id=8, name="Intelligent RFP Response Engine", function="Pre-Sales / Bid Mgmt", decision="validate",
         business_value=4, feasibility=3, strategic_fit=5, complexity=2, impact="~$1.2M/yr", impact_raw=1.2,
         problem="Bid teams spend 60–80 hrs per RFP on content retrieval and drafting, severely limiting the number of bids pursued.",
         benefit="50% reduction in drafting time; 30% more bids pursued with same headcount; improved win rate consistency.",
         users="Bid managers, Pre-sales consultants, Subject matter experts, Practice heads",
         inputs="Historical RFP responses, case studies, capability statements, pricing templates, win/loss data",
         risk="Accuracy and brand alignment of AI-drafted content; IP protection of bid collateral; quality review workflow.",
         complexity_note="Medium — RAG over proprietary corpus; human review essential; quality gates before submission"),

    dict(id=9, name="Automated Meeting Summariser", function="Collaboration / All Staff", decision="defer",
         business_value=3, feasibility=4, strategic_fit=2, complexity=1, impact="~$0.3M/yr", impact_raw=0.3,
         problem="Participants manually take minutes; action items frequently missed; no structured follow-up mechanism.",
         benefit="Auto-generated meeting summaries and action items; time saving for all staff; improved follow-through.",
         users="All staff, Team leads, Executive assistants",
         inputs="Meeting recordings, calendar metadata, participant list",
         risk="Privacy and consent management; meeting recording policy; largely available via existing M365 Copilot license.",
         complexity_note="Low — commodity tooling already available; limited differentiation over M365 Copilot"),

    dict(id=10, name="AI Attendance & Workforce Demand Forecasting", function="HR / Workforce Planning", decision="defer",
         business_value=3, feasibility=3, strategic_fit=2, complexity=2, impact="~$0.4M/yr", impact_raw=0.4,
         problem="Workforce planning relies on periodic manual forecasts with limited accuracy — causing hiring lag and bench gaps.",
         benefit="Better resource availability prediction; reduced time-to-hire lag; improved bench utilisation.",
         users="HR Business Partners, Workforce planning team, Resource managers",
         inputs="Leave records, project pipeline, historical headcount data, attrition rates",
         risk="Data privacy and consent; low maturity of HR data in current systems; union/works council considerations.",
         complexity_note="Medium — HR data governance required before AI is viable; data quality is the key blocker"),

    dict(id=11, name="AI-Assisted Code Review & Quality Gate", function="Engineering", decision="defer",
         business_value=3, feasibility=3, strategic_fit=3, complexity=2, impact="~$0.6M/yr", impact_raw=0.6,
         problem="Code review is a delivery bottleneck; quality is inconsistent across squads and geographies.",
         benefit="Faster review cycles; standardised quality enforcement; reduced post-production defect rate.",
         users="Software engineers, Tech leads, QA engineers, DevOps teams",
         inputs="Source code repositories, coding standards documentation, historical defect data",
         risk="Developer resistance to AI review; false positives eroding trust; language/framework coverage gaps.",
         complexity_note="Medium — tooling exists (GitHub Copilot) but enterprise integration and tuning needed"),

    dict(id=12, name="Auto Email Drafting Assistant", function="General / All Staff", decision="pass",
         business_value=2, feasibility=5, strategic_fit=1, complexity=1, impact="Minimal", impact_raw=0.0,
         problem="Staff spend time composing routine emails and follow-up communications.",
         benefit="Minor time saving on routine communication; marginal productivity uplift.",
         users="All staff",
         inputs="Email thread context, calendar events",
         risk="Brand tone consistency; already available via Outlook Copilot in existing M365 license.",
         complexity_note="Very Low — commodity capability already covered by existing M365 Copilot license"),

    # ── IT Architecture use cases (IDs 13–15) ──────────────────────────────────
    dict(id=13, name="AI-Driven Infrastructure Capacity Planning", function="IT Architecture", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=2, impact="~$1.4M/yr", impact_raw=1.4,
         problem="Infrastructure capacity planning is manual and reactive — over-provisioning costs ~18% of cloud budget while under-provisioning causes outages.",
         benefit="Reduce over-provisioning by 25%; predict capacity needs 90 days ahead; eliminate unplanned outage costs ~$400K/yr.",
         users="IT Architects, Infrastructure leads, Cloud ops teams, Finance",
         inputs="Cloud billing data, utilisation metrics (CPU/RAM/storage), application growth trends, CMDB",
         risk="Multi-cloud data normalisation complexity; model accuracy in volatile workload periods; change freeze windows.",
         complexity_note="Medium — well-established time-series forecasting; integration with AWS/Azure Cost Explorer APIs needed"),

    dict(id=14, name="Architecture Decision Record (ADR) Intelligence", function="IT Architecture", decision="validate",
         business_value=4, feasibility=3, strategic_fit=5, complexity=2, impact="~$0.9M/yr", impact_raw=0.9,
         problem="Architecture decisions are undocumented or siloed — teams repeat costly mistakes and onboarding of new architects takes 3–6 months.",
         benefit="40% faster onboarding for architects; 60% reduction in repeated design mistakes; reusable decision corpus for pre-sales.",
         users="Principal architects, Solution architects, Tech leads, Pre-sales engineers",
         inputs="Confluence ADR pages, architecture review board minutes, design documents, RFC history",
         risk="Document quality variance; sensitive IP in design docs; corpus curation effort; hallucination on complex trade-offs.",
         complexity_note="Medium — RAG over internal Confluence/SharePoint; requires structured ADR template enforcement first"),

    dict(id=15, name="AI Security Vulnerability Pattern Detector", function="IT Architecture", decision="validate",
         business_value=5, feasibility=3, strategic_fit=4, complexity=3, impact="~$2.2M/yr", impact_raw=2.2,
         problem="Security architecture reviews are point-in-time; vulnerabilities introduced mid-sprint go undetected until pen-test cycles, costing $800K avg remediation/yr.",
         benefit="Real-time vulnerability pattern detection; 70% reduction in critical findings at pen-test; shift-left security savings ~$1.5M/yr.",
         users="Security architects, DevSecOps engineers, CISO, Delivery leads",
         inputs="Infrastructure-as-code (Terraform/CloudFormation), API specs, network diagrams, CVE databases",
         risk="False positive fatigue; IaC coverage gaps; proprietary cloud config sensitivity; regulatory data handling.",
         complexity_note="Medium-High — requires SAST/IaC scanning integration + LLM reasoning layer; security domain fine-tuning needed"),

    # ── Programme Management Office use cases (IDs 16–18) ──────────────────────
    dict(id=16, name="AI Portfolio Health Scorecard", function="Programme Management", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=1, impact="~$1.1M/yr", impact_raw=1.1,
         problem="Portfolio health reporting takes 3 days/month of manual effort across 30+ projects; RAG/AMBER/GREEN status is subjective and inconsistent.",
         benefit="Real-time portfolio health dashboard; consistent AI-scored RAG status; 80% reduction in manual reporting effort (~$350K/yr saved).",
         users="PMO Director, Portfolio managers, Programme sponsors, Steering committee",
         inputs="Jira epics, MS Project schedules, budget trackers, risk registers, milestone logs",
         risk="Data quality across heterogeneous project tools; stakeholder trust in AI-generated RAG scores; governance sign-off.",
         complexity_note="Low-Medium — aggregation and NLP summarisation on structured data; dashboard integration via Jira/MS Project APIs"),

    dict(id=17, name="Predictive Project Risk Early Warning", function="Programme Management", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=2, impact="~$1.8M/yr", impact_raw=1.8,
         problem="Projects surface risks late — 68% of escalations could have been flagged 4–6 weeks earlier based on signals already in project data.",
         benefit="Early risk identification 4–6 weeks ahead; reduce project overruns by 30%; save ~$1.8M/yr in rework and delay costs.",
         users="PMO managers, Project sponsors, Delivery leads, Programme directors",
         inputs="Sprint velocity trends, budget burn rates, resource utilisation, issue logs, dependency maps",
         risk="Model interpretability for executive audiences; data lag in source systems; alert fatigue if thresholds not tuned.",
         complexity_note="Medium — ML classification on time-series project signals; requires 2+ years of historical project data"),

    dict(id=18, name="Automated Lessons Learned Knowledge Base", function="Programme Management", decision="defer",
         business_value=3, feasibility=4, strategic_fit=3, complexity=1, impact="~$0.4M/yr", impact_raw=0.4,
         problem="Post-project lessons learned are captured in ad-hoc documents and never reused — same mistakes recur across 40% of projects.",
         benefit="Searchable lessons learned corpus; AI-recommended risk mitigations at project start; 20% reduction in recurring issues.",
         users="Project managers, PMO analysts, Delivery leads, Quality assurance",
         inputs="Project closure reports, retrospective notes, RAID logs, incident post-mortems",
         risk="Document quality and completeness; adoption resistance; classification accuracy on unstructured text.",
         complexity_note="Low — RAG over document corpus; lightweight classification; fast to pilot with existing document store"),

    # ── AI Strategy use cases (IDs 19–21) ─────────────────────────────────────
    dict(id=19, name="Enterprise AI Maturity Assessment Automation", function="AI Strategy", decision="pursue",
         business_value=5, feasibility=5, strategic_fit=5, complexity=1, impact="~$0.7M/yr", impact_raw=0.7,
         problem="AI maturity assessments across 12 business units take 6 weeks of manual effort per cycle — delaying strategic investment decisions by an entire quarter.",
         benefit="Continuous AI maturity scoring; 85% reduction in assessment effort; data-driven investment prioritisation across all BUs.",
         users="AI Strategy Lead, CTO, CDO, Business unit heads, Transformation office",
         inputs="Survey responses, project pipeline data, AI tool adoption metrics, budget allocations, capability registers",
         risk="Survey response quality; bias in self-reported data; change in maturity framework between cycles.",
         complexity_note="Low — structured data aggregation + LLM narrative generation; scoring rubric is well-defined"),

    dict(id=20, name="AI Use Case ROI Tracker & Benefits Realisation", function="AI Strategy", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=2, impact="~$1.3M/yr", impact_raw=1.3,
         problem="AI investments lack post-implementation tracking — only 30% of AI initiatives formally measure ROI, making portfolio optimisation impossible.",
         benefit="Real-time benefits realisation dashboard; identify underperforming initiatives early; optimise AI portfolio allocation saving ~$1.3M/yr.",
         users="AI Strategy Lead, CFO, CTO, Programme sponsors, Finance controllers",
         inputs="Project actuals vs estimates, KPI measurement data, tool usage metrics, business outcome dashboards",
         risk="KPI data availability and consistency across business units; attribution of value to AI vs other factors.",
         complexity_note="Medium — requires cross-system data integration; benefit attribution modelling; executive-grade visualisation"),

    dict(id=21, name="AI Talent & Skill Gap Intelligence", function="AI Strategy", decision="validate",
         business_value=4, feasibility=3, strategic_fit=5, complexity=2, impact="~$1.0M/yr", impact_raw=1.0,
         problem="The organisation lacks real-time visibility into AI skills inventory — resulting in $2M+/yr in external consulting spend that could be covered internally.",
         benefit="Identify internal AI skill gaps and surpluses; reduce external consulting by 20%; targeted upskilling investment saves ~$1M/yr.",
         users="AI Strategy Lead, CHRO, Learning & Development, Talent acquisition, BU heads",
         inputs="HR skill profiles, training completion records, project role assignments, job descriptions, LinkedIn data",
         risk="Employee data privacy; skill self-assessment accuracy; rapidly evolving AI skill taxonomy.",
         complexity_note="Medium — NLP over HR/skills data; taxonomy management required; integration with LMS and HR systems"),
]


def seed():
    init_db()
    db = SessionLocal()
    try:
        existing_ids = {row.id for row in db.query(UseCase.id).all()}
        new_rows = [r for r in SEED_DATA if r["id"] not in existing_ids]
        for row in new_rows:
            try:
                db.add(UseCase(**row))
                db.commit()
            except Exception:
                db.rollback()
        total = db.query(UseCase).count()
        if new_rows:
            print(f"Seeded {len(new_rows)} new use case(s). Total in DB: {total}.")
        else:
            print(f"DB already up to date ({total} use cases).")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
