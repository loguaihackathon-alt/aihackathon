# auth.py — Persona registry, roles, and access control

# ── Persona Definitions ───────────────────────────────────────────────────────
# Each persona has:
#   password      : plain-text (demo only)
#   role          : admin | executive | manager
#   title         : display title
#   functions     : list of UseCase.function values this persona can see
#                   (empty list = see ALL — used for admin)
#   tabs          : tab indices visible (0=Matrix,1=Backlog,2=Scoring,3=Roadmap,4=AI Analysis,5=Add)
#   can_add       : can submit new use cases
#   can_run_agent : can trigger the AI agent pipeline

PERSONAS: dict[str, dict] = {
    "ceo": {
        "password":      "ceo123",
        "name":          "CEO",
        "title":         "Chief Executive Officer",
        "avatar":        "👑",
        "role":          "admin",
        "functions":     [],                        # empty = all functions
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#1A1612",
    },
    "cto": {
        "password":      "cto123",
        "name":          "CTO",
        "title":         "Chief Technology Officer",
        "avatar":        "⚙️",
        "role":          "executive",
        "functions":     ["IT Operations", "Engineering", "Architecture"],
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#185FA5",
    },
    "coo": {
        "password":      "coo123",
        "name":          "COO",
        "title":         "Chief Operating Officer",
        "avatar":        "🏗️",
        "role":          "executive",
        "functions":     ["PMO", "Delivery / PMO", "Governance / PMO"],
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#0F6E56",
    },
    "cfo": {
        "password":      "cfo123",
        "name":          "CFO",
        "title":         "Chief Financial Officer",
        "avatar":        "💼",
        "role":          "executive",
        "functions":     ["Legal / Procurement", "Pre-Sales / Bid Mgmt"],
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#534AB7",
    },
    "chro": {
        "password":      "chro123",
        "name":          "CHRO",
        "title":         "Chief HR Officer",
        "avatar":        "🧑‍🤝‍🧑",
        "role":          "executive",
        "functions":     ["HR / Workforce Planning", "Collaboration / All Staff",
                          "General / All Staff"],
        "tabs":          [0, 1, 2, 3],
        "can_add":       False,
        "can_run_agent": False,
        "theme":         "#993556",
    },
    "sdhead": {
        "password":      "sd123",
        "name":          "Service Desk Head",
        "title":         "Head of Service Desk",
        "avatar":        "🎧",
        "role":          "manager",
        "functions":     ["Service Desk"],
        "tabs":          [1, 2],
        "can_add":       False,
        "can_run_agent": False,
        "theme":         "#854F0B",
    },
    "itarchitect": {
        "password":      "arch123",
        "name":          "IT Architect",
        "title":         "Principal IT Architect",
        "avatar":        "🏛️",
        "role":          "manager",
        "functions":     ["Architecture", "IT Operations", "Engineering",
                          "IT Architecture"],
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#185FA5",
    },
    "pmomanager": {
        "password":      "pmo123",
        "name":          "PMO Manager",
        "title":         "Programme Management Office Manager",
        "avatar":        "📋",
        "role":          "manager",
        "functions":     ["PMO", "Delivery / PMO", "Governance / PMO",
                          "Programme Management"],
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#0F6E56",
    },
    "aistrategy": {
        "password":      "ai123",
        "name":          "AI Strategy Lead",
        "title":         "AI Strategy & Innovation Lead",
        "avatar":        "🧠",
        "role":          "executive",
        "functions":     [],               # sees all — cross-functional remit
        "tabs":          [0, 1, 2, 3, 4, 5],
        "can_add":       True,
        "can_run_agent": True,
        "theme":         "#534AB7",
    },
}

TAB_LABELS = {
    0: "📊 Matrix",
    1: "📋 Backlog",
    2: "🏆 Scoring",
    3: "🗺️ Roadmap",
    4: "🤖 AI Analysis",
    5: "➕ Add Use Case",
}


def authenticate(username: str, password: str) -> dict | None:
    """Return persona dict if credentials match, else None."""
    persona = PERSONAS.get(username.lower().strip())
    if persona and persona["password"] == password:
        return {"username": username.lower().strip(), **persona}
    return None


def filter_use_cases(use_cases: list[dict], persona: dict) -> list[dict]:
    """Return only use cases this persona is allowed to see."""
    if not persona["functions"]:          # admin sees all
        return use_cases
    allowed = {f.lower() for f in persona["functions"]}
    return [u for u in use_cases if u["function"].lower() in allowed]
