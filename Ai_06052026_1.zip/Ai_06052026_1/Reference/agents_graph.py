import os
import urllib3
import httpx
from typing import TypedDict, Annotated, Sequence
from dotenv import load_dotenv

# Core LangChain & LangGraph abstractions
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

# LlamaIndex retrieval dependencies
from llama_index.core import StorageContext, load_index_from_storage
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings

# Init systems setup variables
load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY = os.getenv("GENAI_API_KEY")
BASE_URL = os.getenv("GENAI_BASE_URL")
LLM_MODEL = os.getenv("GENAI_LLM_MODEL")
EMBEDDING_MODEL = os.getenv("GENAI_EMBEDDING_MODEL")

custom_http_client = httpx.Client(verify=False)

# Match embedding models configuration across packages
Settings.embed_model = OpenAIEmbedding(
    base_url=BASE_URL,
    model_name=EMBEDDING_MODEL,
    api_key=API_KEY,
    http_client=custom_http_client,
    embed_batch_size=1
)

# ============================================================
# DEFINITION: WORKFLOW TOOLS & RUNTIME ASSETS (RAG)
# ============================================================

@tool
def query_company_knowledge_base(query: str) -> str:
    """Useful when you need to answer questions regarding internal enterprise policies, 
    operational regulations, guidelines, annual leaves, and workspace parameters."""
    try:
        # Load the serialized storage structure constructed in Phase 1
        storage_context = StorageContext.from_defaults(persist_dir="./storage_faiss")
        index = load_index_from_storage(storage_context)
        
        # Build query engine optimized to deliver succinct contextual answers
        query_engine = index.as_query_engine(response_mode="compact")
        response = query_engine.query(query)
        return str(response)
    except Exception as e:
        return f"Operational failure reading index vector storage layer: {str(e)}"

# Register execution context mapping array matrix
tools_inventory = [query_company_knowledge_base]
tool_node_executor = ToolNode(tools_inventory)

# ============================================================
# TEMPLATE MANAGER: AGENT PROMPTS DECLARATIONS
# ============================================================

SYSTEM_AGENT_TEMPLATE = """You are a highly analytical, corporate operational helper assistant agent.
Your core priority is addressing worker requests accurately using available enterprise tools.

Execution Instructions:
1. When asked about company policies, leave conditions, or corporate workflows, ALWAYS invoke `query_company_knowledge_base`.
2. Do not infer parameters or fabricate rules. Rely completely on context from the knowledge store tools.
3. Be direct, clear, professional, and omit internal engineering metrics from final output statements.
"""

agent_prompt_blueprint = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_AGENT_TEMPLATE),
    MessagesPlaceholder(variable_name="messages")
])

# Initialize LangChain OpenAI LLM Object targeting custom infrastructure boundaries
base_llm = ChatOpenAI(
    base_url=BASE_URL,
    model=LLM_MODEL,
    api_key=API_KEY,
    http_client=custom_http_client,
    temperature=0.2
)

# Bind the toolkit directly onto the model interface boundaries
llm_with_tools = base_llm.bind_tools(tools_inventory)

# ============================================================
# ORCHESTRATION ENGINE: LANGGRAPH ARCHITECTURE
# ============================================================

class AgentGraphState(TypedDict):
    """The functional state definition container propagated across graph nodes operations."""
    messages: Annotated[Sequence[BaseMessage], add_messages]


def assistant_node(state: AgentGraphState) -> dict:
    """Primary node handler executing runtime contextual prompt tracking analysis."""
    formatted_prompt = agent_prompt_blueprint.invoke({"messages": state["messages"]})
    llm_runtime_response = llm_with_tools.invoke(formatted_prompt)
    return {"messages": [llm_runtime_response]}


def conditional_router_edge(state: AgentGraphState):
    """Inspects messages context to decide if it returns to user or invokes tool loops."""
    latest_message = state["messages"][-1]
    
    # Routing validation logic checking for tool execution requirements
    if latest_message.tool_calls:
        print(f"-> Router: Tool-Call detected ('{latest_message.tool_calls[0]['name']}'). Routing to Tool Node.")
        return "execute_tools_node"
    
    print("-> Router: Target response successfully resolved. Routing to End Node.")
    return END

# Instantiate structural StateGraph builder blueprint mechanics
workflow_builder = StateGraph(AgentGraphState)

# Append computing nodes locations within internal operational matrices
workflow_builder.add_node("primary_agent_node", assistant_node)
workflow_builder.add_node("execute_tools_node", tool_node_executor)

# Bind static architectural connection frameworks
workflow_builder.add_edge(START, "primary_agent_node")
workflow_builder.add_edge("execute_tools_node", "primary_agent_node")

# Mount runtime evaluation logic pathways via conditional routing connections
workflow_builder.add_conditional_edges(
    "primary_agent_node",
    conditional_router_edge
)

# Compile framework into an executable engine
compiled_agent_orchestrator = workflow_builder.compile()

# ============================================================
# FRAMEWORK VERIFICATION RUNNER
# ============================================================

if __name__ == "__main__":
    print("\n--- System Execution Phase 1: Checking if RAG indices exist ---")
    if not os.path.exists("./storage_faiss"):
        print("⚠ FAISS Index Storage folder missing! Creating data index first...")
        from ingestion_rag import run_ingestion_pipeline
        run_ingestion_pipeline()

    print("\n--- System Execution Phase 2: Querying the LangGraph Multi-Agent Runtime ---")
    
    user_query = "Hello, can you look up how many annual leave days I can request according to policy?"
    print(f"User Input: '{user_query}'\n")

    initial_state = {
        "messages": [HumanMessage(content=user_query)]
    }

    # Execute system computations through sequential orchestration operations loops
    events_generator = compiled_agent_orchestrator.stream(initial_state, stream_mode="values")
    
    for event in events_generator:
        if "messages" in event and event["messages"]:
            newest_msg = event["messages"][-1]
            if isinstance(newest_msg, AIMessage) and newest_msg.content:
                print(f"\n[Agent Final Response Output]:\n{newest_msg.content}")