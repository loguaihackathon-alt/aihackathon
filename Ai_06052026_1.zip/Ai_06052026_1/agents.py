"""
Multi-Agent Pipeline using LangGraph:
  Analyst Agent   → analyses the use case problem & benefit
  Scorer Agent    → validates/adjusts scores with rationale
  Prioritizer Agent → produces final decision & roadmap placement

LLM & embedding config sourced from GENAI_* env vars (matches reference pattern).
"""

import os
import urllib3
import httpx
from typing import TypedDict
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY   = os.getenv("GENAI_API_KEY")
BASE_URL  = os.getenv("GENAI_BASE_URL")
LLM_MODEL = os.getenv("GENAI_LLM_MODEL")

custom_http_client = httpx.Client(verify=False)

_llm = None


def get_llm():
    global _llm
    if _llm is None:
        _llm = ChatOpenAI(
            base_url=BASE_URL,
            model=LLM_MODEL,
            api_key=API_KEY,
            http_client=custom_http_client,
            temperature=0.2,
        )
    return _llm


class AgentState(TypedDict):
    use_case: dict
    analyst_output: str
    scorer_output: str
    prioritizer_output: str
    final_summary: str


def analyst_agent(state: AgentState) -> AgentState:
    uc = state["use_case"]
    llm = get_llm()
    messages = [
        SystemMessage(content=(
            "You are a senior AI opportunity analyst. "
            "Analyse the given use case and produce a concise 3-bullet assessment covering: "
            "1) core business problem severity, 2) benefit credibility, 3) data/dependency readiness."
        )),
        HumanMessage(content=(
            f"Use Case: {uc['name']}\n"
            f"Function: {uc['function']}\n"
            f"Problem: {uc['problem']}\n"
            f"Benefit: {uc['benefit']}\n"
            f"Inputs required: {uc['inputs']}\n"
            f"Key risks: {uc['risk']}"
        )),
    ]
    response = llm.invoke(messages)
    return {**state, "analyst_output": response.content}


def scorer_agent(state: AgentState) -> AgentState:
    uc = state["use_case"]
    llm = get_llm()
    messages = [
        SystemMessage(content=(
            "You are a scoring validation agent. Given current scores and the analyst assessment, "
            "validate or suggest adjusted scores (1-5) for Business Value, Feasibility, and Strategic Fit. "
            "Respond in this exact format:\n"
            "Business Value: X/5 — <one-line rationale>\n"
            "Feasibility: X/5 — <one-line rationale>\n"
            "Strategic Fit: X/5 — <one-line rationale>\n"
            "Score Validation: CONFIRMED or ADJUSTED"
        )),
        HumanMessage(content=(
            f"Current scores — Business Value: {uc['business_value']}/5, "
            f"Feasibility: {uc['feasibility']}/5, Strategic Fit: {uc['strategic_fit']}/5\n"
            f"Analyst Assessment:\n{state['analyst_output']}\n"
            f"Complexity: {uc['complexity_note']}"
        )),
    ]
    response = llm.invoke(messages)
    return {**state, "scorer_output": response.content}


def prioritizer_agent(state: AgentState) -> AgentState:
    uc = state["use_case"]
    llm = get_llm()
    total = uc["business_value"] + uc["feasibility"] + uc["strategic_fit"]
    messages = [
        SystemMessage(content=(
            "You are an AI investment prioritization advisor for enterprise leadership. "
            "Based on all inputs, confirm or revise the decision (pursue/validate/defer/pass) "
            "and suggest a specific implementation phase (Phase 1: 0-3m / Phase 2: 3-9m / Phase 3: 9-18m). "
            "Keep your output to 4 lines max."
        )),
        HumanMessage(content=(
            f"Use Case: {uc['name']} | Function: {uc['function']}\n"
            f"Composite Score: {total}/15 | Current Decision: {uc['decision'].upper()}\n"
            f"Scorer Output:\n{state['scorer_output']}\n"
            f"Estimated Impact: {uc['impact']}"
        )),
    ]
    response = llm.invoke(messages)
    summary = (
        f"**{uc['name']}** ({uc['function']})\n\n"
        f"**Analyst Assessment:**\n{state['analyst_output']}\n\n"
        f"**Score Validation:**\n{state['scorer_output']}\n\n"
        f"**Prioritization Decision:**\n{response.content}"
    )
    return {**state, "prioritizer_output": response.content, "final_summary": summary}


def build_graph() -> StateGraph:
    graph = StateGraph(AgentState)
    graph.add_node("analyst", analyst_agent)
    graph.add_node("scorer", scorer_agent)
    graph.add_node("prioritizer", prioritizer_agent)
    graph.add_edge(START, "analyst")
    graph.add_edge("analyst", "scorer")
    graph.add_edge("scorer", "prioritizer")
    graph.add_edge("prioritizer", END)
    return graph.compile()


def run_pipeline(use_case: dict) -> dict:
    """Run the 3-agent pipeline for a given use case dict."""
    compiled = build_graph()
    initial_state: AgentState = {
        "use_case": use_case,
        "analyst_output": "",
        "scorer_output": "",
        "prioritizer_output": "",
        "final_summary": "",
    }
    result = compiled.invoke(initial_state)
    return {
        "analyst_output": result["analyst_output"],
        "scorer_output": result["scorer_output"],
        "prioritizer_output": result["prioritizer_output"],
        "final_summary": result["final_summary"],
    }
