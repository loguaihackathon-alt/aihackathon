import os
import time
from datetime import datetime

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from models import init_db, SessionLocal, UseCase, AgentRun
from agents import run_pipeline
from seed_db import seed

load_dotenv()

# ── DB bootstrap (runs once on cold start) ───────────────
init_db()
seed()

# ── Page config ──────────────────────────────────────────
st.set_page_config(
    page_title="AI Opportunity Prioritization",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS ───────────────────────────────────────────
st.markdown("""
<style>
  .main .block-container { padding-top: 1.5rem; }
  .kpi-box { background:#1A1612; border-radius:10px; padding:1.2rem 1rem;
             text-align:center; color:#fff; }
  .kpi-num { font-size:2.2rem; font-weight:700; line-height:1; }
  .kpi-lbl { font-size:0.65rem; text-transform:uppercase; letter-spacing:.08em;
             color:rgba(255,255,255,.5); margin-top:4px; }
  .dec-pursue  { background:#C0DD97; color:#27500A; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-validate{ background:#B5D4F4; color:#0C447C; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-defer   { background:#FAC775; color:#633806; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .dec-pass    { background:#D3D1C7; color:#444441; border-radius:20px;
                 padding:2px 10px; font-size:.75rem; font-weight:600; }
  .matrix-cell { border-radius:10px; padding:14px; min-height:140px; }
  .q1 { background:linear-gradient(135deg,#EAF3DE,#F0F8E8); }
  .q2 { background:linear-gradient(135deg,#E6F1FB,#EFF5FD); }
  .q3 { background:linear-gradient(135deg,#FAEEDA,#FDF4E7); }
  .q4 { background:linear-gradient(135deg,#F1EFE8,#F7F5F0); }
  .chip { display:inline-block; background:#fff; border:1px solid rgba(0,0,0,.1);
          border-radius:6px; padding:3px 8px; font-size:.75rem; margin:2px; }
</style>
""", unsafe_allow_html=True)


# ── DB helpers (direct SQLAlchemy — no HTTP) ─────────────
def get_use_cases(decision: str = "") -> list[dict]:
    db = SessionLocal()
    try:
        q = db.query(UseCase)
        if decision:
            q = q.filter(UseCase.decision == decision)
        rows = q.all()
        return [_uc_dict(u) for u in sorted(rows, key=lambda u: u.business_value + u.feasibility + u.strategic_fit, reverse=True)]
    finally:
        db.close()


def get_kpis() -> dict:
    db = SessionLocal()
    try:
        rows = db.query(UseCase).all()
        return {
            "total": len(rows),
            "pursue": sum(1 for u in rows if u.decision == "pursue"),
            "validate": sum(1 for u in rows if u.decision == "validate"),
            "defer": sum(1 for u in rows if u.decision == "defer"),
            "pass_count": sum(1 for u in rows if u.decision == "pass"),
            "total_impact_m": round(sum(u.impact_raw or 0 for u in rows), 1),
        }
    finally:
        db.close()


def add_use_case(payload: dict) -> UseCase:
    db = SessionLocal()
    try:
        uc = UseCase(**payload)
        db.add(uc)
        db.commit()
        db.refresh(uc)
        return uc
    finally:
        db.close()


def save_agent_runs(uc_id: int, result: dict, elapsed_ms: int):
    db = SessionLocal()
    try:
        now = datetime.utcnow().isoformat()
        llm_model = os.getenv("GENAI_LLM_MODEL", "")
        for agent_name in ("analyst_output", "scorer_output", "prioritizer_output"):
            db.add(AgentRun(
                use_case_id=uc_id,
                agent_name=agent_name.replace("_output", ""),
                output=result[agent_name],
                llm_model=llm_model,
                elapsed_ms=elapsed_ms,
                created_at=now,
            ))
        db.commit()
    finally:
        db.close()


def get_agent_runs(uc_id: int) -> list[dict]:
    db = SessionLocal()
    try:
        runs = db.query(AgentRun).filter(AgentRun.use_case_id == uc_id).order_by(AgentRun.id.desc()).all()
        return [{"agent": r.agent_name, "output": r.output,
                 "llm_model": r.llm_model, "elapsed_ms": r.elapsed_ms,
                 "created_at": r.created_at} for r in runs]
    finally:
        db.close()


def _uc_dict(u: UseCase) -> dict:
    return {
        "id": u.id, "name": u.name, "function": u.function,
        "decision": u.decision,
        "business_value": u.business_value, "feasibility": u.feasibility,
        "strategic_fit": u.strategic_fit, "complexity": u.complexity,
        "total_score": u.business_value + u.feasibility + u.strategic_fit,
        "impact": u.impact, "impact_raw": u.impact_raw or 0,
        "problem": u.problem, "benefit": u.benefit, "users": u.users,
        "inputs": u.inputs, "risk": u.risk, "complexity_note": u.complexity_note,
    }


# ── UI helpers ───────────────────────────────────────────
def decision_badge(d: str) -> str:
    cls   = {"pursue": "dec-pursue", "validate": "dec-validate",
             "defer": "dec-defer",   "pass": "dec-pass"}.get(d, "dec-pass")
    label = {"pursue": "Pursue Now", "validate": "Validate",
             "defer": "Defer",       "pass": "Pass"}.get(d, d)
    return f'<span class="{cls}">{label}</span>'


def score_bar(val: int, max_val: int = 5, color: str = "#1A1612") -> str:
    pct = int(val / max_val * 100)
    return (f'<div style="display:flex;align-items:center;gap:6px">'
            f'<div style="flex:1;height:5px;background:#EEE;border-radius:3px;overflow:hidden">'
            f'<div style="width:{pct}%;height:100%;background:{color};border-radius:3px"></div></div>'
            f'<span style="font-size:.75rem;color:#666;min-width:24px">{val}/5</span></div>')


# ════════════════════════════════════════════════════════
# HEADER + KPIs
# ════════════════════════════════════════════════════════
st.markdown("## 🤖 AI Opportunity Backlog & Prioritization Matrix")
st.caption("Enterprise-wide · 6 Business Functions · June 2025 · Strategic Planning Cycle")

kpis = get_kpis()
c1, c2, c3, c4, c5 = st.columns(5)
for col, num, lbl, color in [
    (c1, kpis["total"],             "Use Cases",        "#fff"),
    (c2, kpis["pursue"],            "Pursue Now",       "#97C459"),
    (c3, kpis["validate"],          "Validate",         "#85B7EB"),
    (c4, kpis["defer"],             "Defer",            "#FAC775"),
    (c5, f"~${kpis['total_impact_m']}M", "Est. Annual Impact", "#9FE1CB"),
]:
    col.markdown(f'<div class="kpi-box"><div class="kpi-num" style="color:{color}">{num}</div>'
                 f'<div class="kpi-lbl">{lbl}</div></div>', unsafe_allow_html=True)

st.divider()
tabs = st.tabs(["📊 Matrix", "📋 Backlog", "🏆 Scoring", "🗺️ Roadmap", "🤖 AI Analysis", "➕ Add Use Case"])

# ════════════════════════════════════════════════════════
# TAB 1 — MATRIX
# ════════════════════════════════════════════════════════
with tabs[0]:
    st.markdown("### Prioritization Matrix — Business Value vs Implementation Complexity")
    all_uc = get_use_cases()

    def chips_for(decision: str) -> str:
        return " ".join(f'<span class="chip">● {u["name"]}</span>'
                        for u in all_uc if u["decision"] == decision)

    _, col_low, col_high = st.columns([0.5, 5, 5])
    col_low.markdown('<div style="text-align:center;font-size:.75rem;font-weight:600;color:#888;'
                     'text-transform:uppercase;letter-spacing:.08em">↑ Lower Complexity</div>',
                     unsafe_allow_html=True)
    col_high.markdown('<div style="text-align:center;font-size:.75rem;font-weight:600;color:#888;'
                      'text-transform:uppercase;letter-spacing:.08em">↑ Higher Complexity</div>',
                      unsafe_allow_html=True)

    for row_lbl, dec1, cls1, dec2, cls2 in [
        ("Higher Value", "pursue",  "q1", "validate", "q2"),
        ("Lower Value",  "defer",   "q3", "pass",     "q4"),
    ]:
        lbl_col, left_col, right_col = st.columns([0.5, 5, 5])
        lbl_col.markdown(f'<div style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:.7rem;'
                         f'font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.08em;'
                         f'height:160px;display:flex;align-items:center">{row_lbl}</div>',
                         unsafe_allow_html=True)
        dec_label = {"pursue": "Pursue Now", "validate": "Validate", "defer": "Defer", "pass": "Pass"}
        cell_title = {"pursue": "Quick Wins", "validate": "Strategic Bets",
                      "defer": "Monitor & Re-evaluate", "pass": "Low Priority"}
        badge_cls  = {"pursue": "dec-pursue", "validate": "dec-validate",
                      "defer": "dec-defer",   "pass": "dec-pass"}
        for col, dec, cell_cls in [(left_col, dec1, cls1), (right_col, dec2, cls2)]:
            col.markdown(
                f'<div class="matrix-cell {cell_cls}">'
                f'<span class="{badge_cls[dec]}">{dec_label[dec]}</span>'
                f'<div style="font-size:.7rem;color:#888;text-transform:uppercase;'
                f'letter-spacing:.08em;margin:8px 0 6px">{cell_title[dec]}</div>'
                f'{chips_for(dec)}</div>',
                unsafe_allow_html=True,
            )

# ════════════════════════════════════════════════════════
# TAB 2 — BACKLOG
# ════════════════════════════════════════════════════════
with tabs[1]:
    st.markdown("### Opportunity Backlog")
    fcol1, fcol2 = st.columns([3, 1])
    with fcol1:
        filter_dec = st.radio("Filter", ["All", "pursue", "validate", "defer", "pass"],
                              horizontal=True, label_visibility="collapsed")
    with fcol2:
        sort_by = st.selectbox("Sort by",
                               ["total_score", "business_value", "feasibility", "impact_raw"],
                               label_visibility="collapsed")

    uc_list = get_use_cases("" if filter_dec == "All" else filter_dec)
    uc_list = sorted(uc_list, key=lambda x: x.get(sort_by, 0), reverse=True)

    icon = {"pursue": "🟢", "validate": "🔵", "defer": "🟡", "pass": "⚫"}
    for uc in uc_list:
        with st.expander(f"{icon.get(uc['decision'], '⚪')}  {uc['name']}  —  {uc['function']}"):
            left, right = st.columns(2)
            with left:
                st.markdown(f"**Decision:** {decision_badge(uc['decision'])}", unsafe_allow_html=True)
                for lbl, val, color in [
                    ("Business Value", uc["business_value"], "#639922"),
                    ("Feasibility",    uc["feasibility"],    "#185FA5"),
                    ("Strategic Fit",  uc["strategic_fit"],  "#534AB7"),
                ]:
                    st.markdown(f"**{lbl}**")
                    st.markdown(score_bar(val, color=color), unsafe_allow_html=True)
                st.markdown(f"**Composite Score:** `{uc['total_score']}/15`")
                st.markdown(f"**Est. Annual Impact:** `{uc['impact']}`")
            with right:
                for lbl, val in [
                    ("Problem",     uc["problem"]),
                    ("Benefits",    uc["benefit"]),
                    ("Users",       uc["users"]),
                    ("Data Inputs", uc["inputs"]),
                    ("Risks",       uc["risk"]),
                    ("Complexity",  uc["complexity_note"]),
                ]:
                    st.markdown(f"**{lbl}:** {val}")

# ════════════════════════════════════════════════════════
# TAB 3 — SCORING
# ════════════════════════════════════════════════════════
with tabs[2]:
    st.markdown("### Scoring Summary — Ranked by Composite Score (max 15)")
    all_uc = get_use_cases()
    df = pd.DataFrame([{
        "Rank": i + 1,
        "Use Case": u["name"],
        "Function": u["function"],
        "Decision": u["decision"].capitalize(),
        "Business Value": u["business_value"],
        "Feasibility":    u["feasibility"],
        "Strategic Fit":  u["strategic_fit"],
        "Total":          u["total_score"],
        "Est. Impact":    u["impact"],
    } for i, u in enumerate(sorted(all_uc, key=lambda x: x["total_score"], reverse=True))])

    st.dataframe(df, use_container_width=True, hide_index=True, column_config={
        "Total":          st.column_config.ProgressColumn("Total",          min_value=0, max_value=15, format="%d"),
        "Business Value": st.column_config.ProgressColumn("Business Value", min_value=0, max_value=5,  format="%d"),
        "Feasibility":    st.column_config.ProgressColumn("Feasibility",    min_value=0, max_value=5,  format="%d"),
        "Strategic Fit":  st.column_config.ProgressColumn("Strategic Fit",  min_value=0, max_value=5,  format="%d"),
    })

# ════════════════════════════════════════════════════════
# TAB 4 — ROADMAP
# ════════════════════════════════════════════════════════
with tabs[3]:
    st.markdown("### Transformation Roadmap — Phased Delivery")
    p1, p2, p3 = st.columns(3)
    with p1:
        st.markdown("#### 🟢 Phase 1 — Foundation")
        st.caption("0 – 3 months · ~$3.4M/yr impact")
        for item in [
            "Deploy AI Incident Trend Analyser — target 35% MTTR reduction",
            "Launch Auto Project Status Reports integrated with PPM toolchain",
            "Pilot AI Governance Action Tracker across 3 steering forums",
            "Index existing KB for Intelligent Support Search — rollout to L1/L2",
        ]:
            st.markdown(f"- {item}")
    with p2:
        st.markdown("#### 🔵 Phase 2 — Scale & Validate")
        st.caption("3 – 9 months · ~$6.6M/yr impact")
        for item in [
            "Ingest 3 years of historical project data for Effort Forecasting AI",
            "Pilot Architecture Pattern Recommender with 2 squads",
            "Legal & procurement validation for Contract Risk Analyser",
            "Integrate Intelligent RFP Engine with bid management workflow",
        ]:
            st.markdown(f"- {item}")
    with p3:
        st.markdown("#### 🟣 Phase 3 — Expand & Embed")
        st.caption("9 – 18 months · Platform investment cycle")
        for item in [
            "Reassess deferred use cases against real performance & data quality",
            "Build cross-function shared AI platform for model reuse",
            "Establish enterprise AI ethics, audit, and risk governance framework",
            "Conduct ROI review and open next opportunity identification cycle",
        ]:
            st.markdown(f"- {item}")

# ════════════════════════════════════════════════════════
# TAB 5 — AI ANALYSIS
# ════════════════════════════════════════════════════════
with tabs[4]:
    st.markdown("### 🤖 Multi-Agent AI Analysis")
    st.info("Select a use case to run the **Analyst → Scorer → Prioritizer** LangGraph pipeline.")

    all_uc = get_use_cases()
    uc_map  = {u["name"]: u for u in all_uc}
    selected_name = st.selectbox("Select Use Case", list(uc_map.keys()))
    selected_uc   = uc_map[selected_name]

    if st.button("▶ Run Agent Pipeline", type="primary"):
        with st.spinner("Running 3-agent pipeline: Analyst → Scorer → Prioritizer…"):
            t0 = time.time()
            try:
                result = run_pipeline(selected_uc)
                elapsed_ms = int((time.time() - t0) * 1000)
                save_agent_runs(selected_uc["id"], result, elapsed_ms)
                st.success(f"Pipeline completed in {elapsed_ms / 1000:.1f}s")
                with st.expander("🔍 Analyst Agent", expanded=True):
                    st.markdown(result["analyst_output"])
                with st.expander("📊 Scorer Agent", expanded=True):
                    st.markdown(result["scorer_output"])
                with st.expander("🎯 Prioritizer Agent", expanded=True):
                    st.markdown(result["prioritizer_output"])
            except Exception as e:
                st.error(f"Pipeline error: {e}")

    st.divider()
    st.markdown("**Previous Agent Runs**")
    runs = get_agent_runs(selected_uc["id"])
    if runs:
        for run in runs[:6]:
            label = f"{run['agent'].capitalize()} Agent — {(run['created_at'] or '')[:19]}  |  model: {run['llm_model'] or '—'}  |  {run['elapsed_ms'] or 0}ms"
            with st.expander(label):
                st.markdown(run["output"] or "")
    else:
        st.caption("No previous runs for this use case.")

# ════════════════════════════════════════════════════════
# TAB 6 — ADD USE CASE
# ════════════════════════════════════════════════════════
with tabs[5]:
    st.markdown("### ➕ Add New AI Opportunity")
    with st.form("add_uc_form"):
        name     = st.text_input("Use Case Name *")
        function = st.text_input("Business Function *")
        decision = st.selectbox("Decision", ["pursue", "validate", "defer", "pass"])
        c1, c2, c3 = st.columns(3)
        bv  = c1.slider("Business Value (1–5)", 1, 5, 3)
        fs  = c2.slider("Feasibility (1–5)",    1, 5, 3)
        sf  = c3.slider("Strategic Fit (1–5)",  1, 5, 3)
        complexity   = st.slider("Complexity (1–3)", 1, 3, 2)
        impact       = st.text_input("Est. Annual Impact", "TBD")
        impact_raw   = st.number_input("Impact Raw ($M)", min_value=0.0, step=0.1, value=0.0)
        problem      = st.text_area("Business Problem")
        benefit      = st.text_area("Expected Benefits")
        users        = st.text_input("Target Users")
        inputs       = st.text_input("Data / Process Inputs")
        risk         = st.text_area("Key Risks & Dependencies")
        complexity_note = st.text_input("Complexity Note")
        submitted    = st.form_submit_button("Add Use Case", type="primary")

    if submitted:
        if not name or not function:
            st.warning("Name and Function are required.")
        else:
            add_use_case(dict(
                name=name, function=function, decision=decision,
                business_value=bv, feasibility=fs, strategic_fit=sf,
                complexity=complexity, impact=impact, impact_raw=impact_raw,
                problem=problem, benefit=benefit, users=users,
                inputs=inputs, risk=risk, complexity_note=complexity_note,
            ))
            st.success(f"✅ Use case '{name}' added successfully!")
            st.rerun()
