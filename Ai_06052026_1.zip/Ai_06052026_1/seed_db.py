from models import init_db, SessionLocal, UseCase

SEED_DATA = [
    dict(id=1, name="AI-Assisted Incident Trend Analysis", function="IT Operations", decision="pursue",
         business_value=5, feasibility=5, strategic_fit=5, complexity=1, impact="~$1.2M/yr", impact_raw=1.2,
         problem="Manual triage of recurring incidents consumes L2/L3 engineer hours and delays MTTR significantly across regions.",
         benefit="30–40% reduction in MTTR; proactive pattern identification before SLA breaches; reduced escalation rate.",
         users="IT Ops managers, NOC teams, Service Desk leads",
         inputs="ITSM ticket data (ServiceNow/Jira), monitoring alerts, CMDB asset register",
         risk="Data quality in legacy ITSM; model drift if infrastructure topology changes significantly.",
         complexity_note="Low — existing ITSM APIs are mature; NLP summarisation is a well-proven pattern"),

    dict(id=2, name="Automated Project Status Summarisation", function="PMO", decision="pursue",
         business_value=5, feasibility=4, strategic_fit=5, complexity=1, impact="~$0.8M/yr", impact_raw=0.8,
         problem="PMs spend 2–4 hrs/week manually compiling status reports across disparate tools — error-prone and inconsistent.",
         benefit="80% time saving on status reporting; consistent real-time dashboards for leadership; improved escalation speed.",
         users="Project managers, Programme directors, Executive sponsors, Portfolio office",
         inputs="Jira, MS Project, Confluence, financial trackers, risk registers",
         risk="Tool integration complexity; governance over AI-generated narratives; hallucination on financial data.",
         complexity_note="Low — API integrations are mature; NLP summarisation with structured data is proven"),

    dict(id=3, name="AI Governance Action Tracker", function="Governance / PMO", decision="pursue",
         business_value=4, feasibility=5, strategic_fit=5, complexity=1, impact="~$0.5M/yr", impact_raw=0.5,
         problem="Action items from governance forums tracked manually in spreadsheets — missed deadlines, no accountability trail.",
         benefit="Full action closure visibility; automated nudges and escalations; real-time status to leadership.",
         users="Governance leads, Steering committee members, PMO, Risk function",
         inputs="Meeting transcripts, email threads, action log spreadsheets, calendar integrations",
         risk="Stakeholder adoption; accuracy of meeting transcript AI; integration with existing tools.",
         complexity_note="Low — can be built on existing collaboration platforms (Teams, Outlook, SharePoint)"),

    dict(id=4, name="Intelligent Knowledge Search (Support)", function="Service Desk", decision="pursue",
         business_value=4, feasibility=5, strategic_fit=4, complexity=1, impact="~$0.9M/yr", impact_raw=0.9,
         problem="Support agents spend ~25% of call time searching fragmented knowledge bases, leading to slow resolution and low FCR.",
         benefit="20–30% faster resolution; improved first-contact resolution rate; reduced agent training time by 40%.",
         users="L1/L2 support agents, Service Desk managers, Quality assurance leads",
         inputs="KB articles, Confluence, SharePoint, resolved ticket corpus, SOP documents",
         risk="Knowledge base freshness and quality; change management for agents; indexing cost for large corpora.",
         complexity_note="Low-Medium — RAG-based semantic search architecture; well-proven, fast to deploy"),

    dict(id=5, name="Intelligent Effort & Capacity Forecasting", function="Delivery / PMO", decision="validate",
         business_value=5, feasibility=3, strategic_fit=5, complexity=2, impact="~$2.1M/yr", impact_raw=2.1,
         problem="Project estimates rely on individual judgement, causing systematic over/under-runs of 20–35% that damage margins.",
         benefit="Reduce estimation error by up to 50%; improve resource utilisation; strengthen commercial negotiations.",
         users="Delivery leads, Resource managers, Finance controllers, Client commercial teams",
         inputs="Historical project actuals (3+ yrs), JIRA timesheets, HR capacity data, contract terms",
         risk="Data completeness for historical actuals; model explainability for client-facing estimates; change adoption.",
         complexity_note="Medium — requires clean historical data ingestion; regression/ML modelling; human validation layer"),

    dict(id=6, name="Architecture Pattern Recommender", function="Architecture", decision="validate",
         business_value=5, feasibility=3, strategic_fit=5, complexity=2, impact="~$1.5M/yr", impact_raw=1.5,
         problem="Solution architects repeatedly solve similar design challenges from scratch — slowing pre-sales and delivery phases.",
         benefit="40% faster architecture design; proven pattern reuse; reduced technical debt across delivery portfolio.",
         users="Solution architects, Principal engineers, Pre-sales teams, Tech leads",
         inputs="Internal design docs, architecture decision records, cloud provider pattern libraries, RFP history",
         risk="Proprietary data security; risk of over-standardisation stifling innovation; corpus curation cost.",
         complexity_note="Medium — requires curated architecture corpus; LLM fine-tuning or RAG with domain experts"),

    dict(id=7, name="Contract Risk & Obligation Analyser", function="Legal / Procurement", decision="validate",
         business_value=5, feasibility=3, strategic_fit=4, complexity=3, impact="~$1.8M/yr", impact_raw=1.8,
         problem="Legal teams manually review hundreds of pages of contracts, risking missed obligations and unpriced commercial risk.",
         benefit="90% reduction in manual review time; earlier risk identification; improved compliance and obligation tracking.",
         users="Legal counsel, Procurement managers, Contract managers, Finance",
         inputs="Contract PDFs, obligation registers, regulatory checklists, precedent libraries",
         risk="Regulatory risk of AI-generated legal interpretation; hallucination on nuanced clauses; PII handling.",
         complexity_note="Medium-High — legal domain sensitivity; human validation workflow mandatory; fine-tuning required"),

    dict(id=8, name="Intelligent RFP Response Engine", function="Pre-Sales / Bid Mgmt", decision="validate",
         business_value=4, feasibility=3, strategic_fit=5, complexity=2, impact="~$1.2M/yr", impact_raw=1.2,
         problem="Bid teams spend 60–80 hrs per RFP on content retrieval and drafting, severely limiting the number of bids pursued.",
         benefit="50% reduction in drafting time; 30% more bids pursued with same headcount; improved win rate consistency.",
         users="Bid managers, Pre-sales consultants, Subject matter experts, Practice heads",
         inputs="Historical RFP responses, case studies, capability statements, pricing templates, win/loss data",
         risk="Accuracy and brand alignment of AI-drafted content; IP protection of bid collateral; quality review workflow.",
         complexity_note="Medium — RAG over proprietary corpus; human review essential; quality gates before submission"),

    dict(id=9, name="Automated Meeting Summariser", function="Collaboration / All Staff", decision="defer",
         business_value=3, feasibility=4, strategic_fit=2, complexity=1, impact="~$0.3M/yr", impact_raw=0.3,
         problem="Participants manually take minutes; action items frequently missed; no structured follow-up mechanism.",
         benefit="Auto-generated meeting summaries and action items; time saving for all staff; improved follow-through.",
         users="All staff, Team leads, Executive assistants",
         inputs="Meeting recordings, calendar metadata, participant list",
         risk="Privacy and consent management; meeting recording policy; largely available via existing M365 Copilot license.",
         complexity_note="Low — commodity tooling already available; limited differentiation over M365 Copilot"),

    dict(id=10, name="AI Attendance & Workforce Demand Forecasting", function="HR / Workforce Planning", decision="defer",
         business_value=3, feasibility=3, strategic_fit=2, complexity=2, impact="~$0.4M/yr", impact_raw=0.4,
         problem="Workforce planning relies on periodic manual forecasts with limited accuracy — causing hiring lag and bench gaps.",
         benefit="Better resource availability prediction; reduced time-to-hire lag; improved bench utilisation.",
         users="HR Business Partners, Workforce planning team, Resource managers",
         inputs="Leave records, project pipeline, historical headcount data, attrition rates",
         risk="Data privacy and consent; low maturity of HR data in current systems; union/works council considerations.",
         complexity_note="Medium — HR data governance required before AI is viable; data quality is the key blocker"),

    dict(id=11, name="AI-Assisted Code Review & Quality Gate", function="Engineering", decision="defer",
         business_value=3, feasibility=3, strategic_fit=3, complexity=2, impact="~$0.6M/yr", impact_raw=0.6,
         problem="Code review is a delivery bottleneck; quality is inconsistent across squads and geographies.",
         benefit="Faster review cycles; standardised quality enforcement; reduced post-production defect rate.",
         users="Software engineers, Tech leads, QA engineers, DevOps teams",
         inputs="Source code repositories, coding standards documentation, historical defect data",
         risk="Developer resistance to AI review; false positives eroding trust; language/framework coverage gaps.",
         complexity_note="Medium — tooling exists (GitHub Copilot) but enterprise integration and tuning needed"),

    dict(id=12, name="Auto Email Drafting Assistant", function="General / All Staff", decision="pass",
         business_value=2, feasibility=5, strategic_fit=1, complexity=1, impact="Minimal", impact_raw=0.0,
         problem="Staff spend time composing routine emails and follow-up communications.",
         benefit="Minor time saving on routine communication; marginal productivity uplift.",
         users="All staff",
         inputs="Email thread context, calendar events",
         risk="Brand tone consistency; already available via Outlook Copilot in existing M365 license.",
         complexity_note="Very Low — commodity capability already covered by existing M365 Copilot license"),
]


def seed():
    init_db()
    db = SessionLocal()
    if db.query(UseCase).count() == 0:
        db.bulk_insert_mappings(UseCase, SEED_DATA)
        db.commit()
        print(f"Seeded {len(SEED_DATA)} use cases.")
    else:
        print("DB already seeded.")
    db.close()


if __name__ == "__main__":
    seed()
