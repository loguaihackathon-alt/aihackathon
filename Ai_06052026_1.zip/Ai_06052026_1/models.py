from sqlalchemy import create_engine, Column, Integer, String, Float, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = "sqlite:///./ai_opportunities.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


class UseCase(Base):
    __tablename__ = "use_cases"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    function = Column(String, nullable=False)
    decision = Column(String, nullable=False)          # pursue | validate | defer | pass
    business_value = Column(Integer, nullable=False)   # 1-5
    feasibility = Column(Integer, nullable=False)      # 1-5
    strategic_fit = Column(Integer, nullable=False)    # 1-5
    complexity = Column(Integer, nullable=False)       # 1-3
    impact = Column(String)
    impact_raw = Column(Float, default=0.0)
    problem = Column(Text)
    benefit = Column(Text)
    users = Column(Text)
    inputs = Column(Text)
    risk = Column(Text)
    complexity_note = Column(Text)

    @property
    def total_score(self):
        return self.business_value + self.feasibility + self.strategic_fit


class AgentRun(Base):
    __tablename__ = "agent_runs"

    id = Column(Integer, primary_key=True, index=True)
    use_case_id = Column(Integer, nullable=False, index=True)
    agent_name = Column(String, nullable=False)        # analyst | scorer | prioritizer
    output = Column(Text)
    llm_model = Column(String)                         # model name from GENAI_LLM_MODEL
    elapsed_ms = Column(Integer, default=0)            # wall-clock time for the agent call
    created_at = Column(String)


class VectorIndexMeta(Base):
    """Tracks state of the FAISS vector index built by ingestion_rag.py."""
    __tablename__ = "vector_index_meta"

    id = Column(Integer, primary_key=True, index=True)
    persist_dir = Column(String, nullable=False)       # e.g. ./storage_faiss
    embedding_model = Column(String)                   # GENAI_EMBEDDING_MODEL value
    doc_count = Column(Integer, default=0)
    is_ready = Column(Boolean, default=False)
    built_at = Column(String)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
