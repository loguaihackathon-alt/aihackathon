# AI Opportunity Prioritization — Multi-Agent Application

A multi-agent AI application built with **FastAPI**, **LangChain**, **LangGraph**, **Streamlit**, and **SQLite**.

## Architecture

```
Streamlit UI (app.py)
       │  HTTP
FastAPI Backend (main.py)
       │
  SQLite DB  ──  LangGraph Pipeline (agents.py)
                   ├── Analyst Agent    (problem & benefit assessment)
                   ├── Scorer Agent     (score validation with rationale)
                   └── Prioritizer Agent (decision + roadmap placement)
```

## Project Structure

```
├── main.py          FastAPI backend — REST API + agent trigger endpoint
├── app.py           Streamlit frontend — Matrix / Backlog / Scoring / Roadmap / AI Analysis
├── agents.py        LangGraph multi-agent pipeline
├── models.py        SQLAlchemy models + SQLite setup
├── seed_db.py       Seeds the 12 use cases from the HTML dashboard
├── requirements.txt Python dependencies
└── .env.example     API key template
```

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure OpenAI key (required only for AI Analysis tab)
copy .env.example .env
# Edit .env and set your OPENAI_API_KEY

# 3. Start FastAPI backend  (Terminal 1)
uvicorn main:app --reload --port 8000

# 4. Start Streamlit frontend  (Terminal 2)
streamlit run app.py
```

Open **http://localhost:8501** in your browser.

## Tabs

| Tab | Description |
|-----|-------------|
| 📊 Matrix | 2×2 prioritization matrix (Value vs Complexity) |
| 📋 Backlog | Filterable / sortable use case cards with full details |
| 🏆 Scoring | Ranked table with progress bar scores |
| 🗺️ Roadmap | 3-phase transformation roadmap |
| 🤖 AI Analysis | Trigger 3-agent LangGraph pipeline per use case |
| ➕ Add Use Case | Add new opportunities to the backlog |

## Agent Pipeline

```
[Analyst] → analyses problem severity, benefit credibility, data readiness
    ↓
[Scorer]  → validates/adjusts Business Value / Feasibility / Strategic Fit scores
    ↓
[Prioritizer] → confirms decision & phase placement with leadership rationale
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/use-cases` | List all use cases (filter by `?decision=pursue`) |
| GET | `/use-cases/{id}` | Get single use case |
| POST | `/use-cases` | Create new use case |
| PUT | `/use-cases/{id}` | Update use case |
| DELETE | `/use-cases/{id}` | Delete use case |
| POST | `/use-cases/{id}/analyse` | Run multi-agent pipeline |
| GET | `/use-cases/{id}/agent-runs` | Get past agent run history |
| GET | `/kpis` | Dashboard KPI summary |
