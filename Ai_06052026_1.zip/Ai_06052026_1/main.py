import os
from datetime import datetime
from time import time
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from dotenv import load_dotenv

from models import init_db, get_db, UseCase, AgentRun
from seed_db import seed
from agents import run_pipeline

load_dotenv()

app = FastAPI(title="AI Opportunity Prioritization API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    init_db()
    seed()


# ── Schemas ──────────────────────────────────────────────
class UseCaseCreate(BaseModel):
    name: str
    function: str
    decision: str
    business_value: int
    feasibility: int
    strategic_fit: int
    complexity: int
    impact: Optional[str] = "TBD"
    impact_raw: Optional[float] = 0.0
    problem: Optional[str] = ""
    benefit: Optional[str] = ""
    users: Optional[str] = ""
    inputs: Optional[str] = ""
    risk: Optional[str] = ""
    complexity_note: Optional[str] = ""


class UseCaseUpdate(UseCaseCreate):
    pass


# ── Use Case Endpoints ────────────────────────────────────
@app.get("/use-cases")
def list_use_cases(decision: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(UseCase)
    if decision:
        q = q.filter(UseCase.decision == decision)
    return [_uc_dict(uc) for uc in q.order_by(
        (UseCase.business_value + UseCase.feasibility + UseCase.strategic_fit).desc()
    ).all()]


@app.get("/use-cases/{uc_id}")
def get_use_case(uc_id: int, db: Session = Depends(get_db)):
    uc = db.get(UseCase, uc_id)
    if not uc:
        raise HTTPException(404, "Use case not found")
    return _uc_dict(uc)


@app.post("/use-cases", status_code=201)
def create_use_case(payload: UseCaseCreate, db: Session = Depends(get_db)):
    uc = UseCase(**payload.model_dump())
    db.add(uc)
    db.commit()
    db.refresh(uc)
    return _uc_dict(uc)


@app.put("/use-cases/{uc_id}")
def update_use_case(uc_id: int, payload: UseCaseUpdate, db: Session = Depends(get_db)):
    uc = db.get(UseCase, uc_id)
    if not uc:
        raise HTTPException(404, "Use case not found")
    for k, v in payload.model_dump().items():
        setattr(uc, k, v)
    db.commit()
    db.refresh(uc)
    return _uc_dict(uc)


@app.delete("/use-cases/{uc_id}", status_code=204)
def delete_use_case(uc_id: int, db: Session = Depends(get_db)):
    uc = db.get(UseCase, uc_id)
    if not uc:
        raise HTTPException(404, "Use case not found")
    db.delete(uc)
    db.commit()


# ── Agent Endpoint ────────────────────────────────────────
@app.post("/use-cases/{uc_id}/analyse")
def analyse_use_case(uc_id: int, db: Session = Depends(get_db)):
    uc = db.get(UseCase, uc_id)
    if not uc:
        raise HTTPException(404, "Use case not found")

    t0 = time()
    result = run_pipeline(_uc_dict(uc))
    elapsed_ms = int((time() - t0) * 1000)
    llm_model = os.getenv("GENAI_LLM_MODEL", "")
    now = datetime.utcnow().isoformat()

    for agent_name in ("analyst_output", "scorer_output", "prioritizer_output"):
        db.add(AgentRun(
            use_case_id=uc_id,
            agent_name=agent_name.replace("_output", ""),
            output=result[agent_name],
            llm_model=llm_model,
            elapsed_ms=elapsed_ms,
            created_at=now,
        ))
    db.commit()
    return result


@app.get("/use-cases/{uc_id}/agent-runs")
def get_agent_runs(uc_id: int, db: Session = Depends(get_db)):
    runs = db.query(AgentRun).filter(AgentRun.use_case_id == uc_id).order_by(AgentRun.id.desc()).all()
    return [{
        "id": r.id, "agent": r.agent_name, "output": r.output,
        "llm_model": r.llm_model, "elapsed_ms": r.elapsed_ms, "created_at": r.created_at,
    } for r in runs]


# ── KPI Endpoint ──────────────────────────────────────────
@app.get("/kpis")
def kpis(db: Session = Depends(get_db)):
    all_uc = db.query(UseCase).all()
    total_impact = sum(u.impact_raw for u in all_uc)
    return {
        "total": len(all_uc),
        "pursue": sum(1 for u in all_uc if u.decision == "pursue"),
        "validate": sum(1 for u in all_uc if u.decision == "validate"),
        "defer": sum(1 for u in all_uc if u.decision == "defer"),
        "pass_count": sum(1 for u in all_uc if u.decision == "pass"),
        "total_impact_m": round(total_impact, 1),
    }


# ── Helpers ───────────────────────────────────────────────
def _uc_dict(uc: UseCase) -> dict:
    return {
        "id": uc.id, "name": uc.name, "function": uc.function,
        "decision": uc.decision,
        "business_value": uc.business_value, "feasibility": uc.feasibility,
        "strategic_fit": uc.strategic_fit, "complexity": uc.complexity,
        "total_score": uc.business_value + uc.feasibility + uc.strategic_fit,
        "impact": uc.impact, "impact_raw": uc.impact_raw,
        "problem": uc.problem, "benefit": uc.benefit, "users": uc.users,
        "inputs": uc.inputs, "risk": uc.risk, "complexity_note": uc.complexity_note,
    }
