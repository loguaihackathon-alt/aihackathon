# AI Hackathon Toolkit

A three-part framework for rapidly building, researching, and delivering AI hackathon solutions.

---

## Project Structure

```
aihack_0605/
├── src/
│   ├── inputs/
│   │   ├── problem_statement.txt   ← Your hackathon problem statement
│   │   └── deliverables.txt        ← Your hackathon deliverables
│   ├── outputs/                    ← All generated outputs land here
│   ├── data/                       ← Local .pdf and .txt files to ingest
│   ├── storage_faiss/              ← Persisted vector index (auto-created)
│   ├── ingestion_rag.py            ← Ingests data sources into FAISS vector store
│   ├── agents_graph.py             ← LangGraph RAG agent for querying the vector store
│   ├── hackathon_agent.py          ← Standalone agent that generates all hackathon outputs
│   ├── presentation_generator.py   ← Generates HTML presentation from output 10
│   └── code_generator_agent.py     ← Deep code generator for multi-agent solutions
├── .env                            ← API keys and data source configuration
└── requirements.txt
```

---

## Setup

**1. Create and activate virtual environment**
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Configure `.env`**
```env
GENAI_API_KEY=your-api-key
GENAI_BASE_URL=https://your-gateway/v1
GENAI_LLM_MODEL=your-llm-model
GENAI_EMBEDDING_MODEL=your-embedding-model

# Data sources for ingestion
LOCAL_FILES_DIR=./data
SCRAPE_URLS=https://example.com/page1,https://example.com/page2
WIKIPEDIA_TOPICS=Topic One,Topic Two
RSS_FEEDS=https://example.com/rss.xml
```

---

## Part 1 — Hackathon Output Generator

> Run this first thing when you have your problem statement. It produces 10 research and planning artifacts automatically.

### Setup

Drop your content into these two files:

**`src/inputs/problem_statement.txt`**
```
Paste your full hackathon problem statement here.
Include domain context, pain points, and target users.
```

**`src/inputs/deliverables.txt`**
```
List what the hackathon expects you to deliver —
prototype, presentation, demo, documentation, etc.
```

### Run

```bash
cd src
python hackathon_agent.py
```

### What gets generated in `src/outputs/`

| File | What it contains |
|------|-----------------|
| `01_synthetic_data_low.md` | 10–15 record synthetic dataset as a markdown table |
| `02_synthetic_data_medium.md` | 40–50 record dataset with diverse scenarios and edge cases |
| `03_industry_challenges_opportunities.md` | Market challenges, opportunities, regulations, stakeholders |
| `04_ai_players_landscape.md` | Competitors, startups, open-source projects, and market gaps |
| `05_web_research_sources.md` | 10+ curated URLs to scrape, key themes, public datasets |
| `06_requirements_specification.md` | Feature spec covering GenAI, Agentic AI, and ML capabilities |
| `07_ai_vs_non_ai_comparison.md` | Side-by-side comparison with ROI estimates for each feature |
| `08_usp_analysis.md` | Differentiators, elevator pitch, go-to-market angle |
| `09_design_architecture_prompts.md` | Ready-to-use prompts for architecture, code, deck, and demo script |
| `10_presentation_html_video_prompt.md` | Comprehensive prompt for Claude/Gemini to generate HTML presentation or video covering business challenges, architecture, agent roles, outcomes, and DeepEval testing |

### How outputs connect to each other

Each node uses the outputs of prior nodes as context, so later outputs are grounded in earlier ones:

```
problem_statement + deliverables
        ↓
synthetic format decision (CSV vs TXT)
        ↓
synthetic data (low + medium)
        ↓
industry analysis → AI players landscape
        ↓
web research sources
        ↓
requirements specification
        ↓
AI vs non-AI comparison
        ↓
USP analysis  (uses competitors + requirements)
        ↓
design & architecture prompts  (uses everything above)
        ↓
presentation HTML/video prompt  (uses all context)
```

### Next steps after running

- Run `presentation_generator.py` to auto-generate the HTML presentation from output 10
- Feed `09_design_architecture_prompts.md` prompts into an AI assistant to generate architecture diagrams, code scaffolds, and slide decks
- Use `05_web_research_sources.md` URLs to populate `SCRAPE_URLS` in `.env` for deeper ingestion
- Drop domain PDFs or documents into `src/data/` to enrich the knowledge base
- Use `01_` and `02_` synthetic datasets (CSV or TXT) to demo your prototype before real data is available
- Use `08_usp_analysis.md` elevator pitch directly in your opening slide
- Alternatively, feed `10_presentation_html_video_prompt.md` directly into Claude/Gemini/GPT for a custom presentation

**Note on synthetic data:** The agent automatically decides whether to generate CSV (structured/tabular) or TXT (unstructured/narrative) files based on your problem domain.

---

## Part 2 — Presentation HTML Generator

> Reads output 10 and generates a complete multi-slide HTML presentation.

### Run

```bash
cd src
python presentation_generator.py
```

Generates `src/outputs/presentation.html` — a self-contained HTML file with:
- 7 slides covering business challenge, solution, architecture, agents, outcomes, evaluation, and demo
- Modern CSS styling with responsive layout
- Visual descriptions for diagrams, charts, and KPIs
- Ready to open in any browser and present to judges

**Note:** This script requires `10_presentation_html_video_prompt.md` to exist. Run `hackathon_agent.py` first if you haven't already.

---

## Part 3 — Data Ingestion Pipeline

> Ingests data from multiple sources into a FAISS vector store for RAG queries.

### Configure data sources in `.env`

| Variable | Description |
|----------|-------------|
| `LOCAL_FILES_DIR` | Folder containing `.pdf` and `.txt` files (default: `./data`) |
| `SCRAPE_URLS` | Comma-separated URLs to web scrape |
| `WIKIPEDIA_TOPICS` | Comma-separated Wikipedia article titles |
| `RSS_FEEDS` | Comma-separated RSS feed URLs |

### Run

```bash
cd src
python ingestion_rag.py
```

Outputs a persisted FAISS index at `src/storage_faiss/`.

---

## Part 4 — RAG Query Agent

> A LangGraph-powered agent that answers questions by querying the vector store built in Part 2.

### Run

```bash
cd src
python agents_graph.py
```

Automatically runs ingestion first if `storage_faiss/` does not exist.

---

## Part 5 — Deep Code Generator

> Generates a complete, production-ready multi-agent orchestration solution based on your problem statement.

### What it generates

A fully functional multi-agent system with:
- **Orchestrator** — Central coordinator managing workflow and state
- **Planner Agent** — Breaks down complex queries into execution steps
- **Researcher Agent** — Gathers relevant information from knowledge base
- **Analyzer Agent** — Processes and analyzes data
- **Reviewer Agent** — Validates outputs and ensures quality
- **Action Performer Agent** — Executes final actions based on analysis
- **Evaluator Agent** — Measures success and provides feedback

*Note: The exact agents generated depend on your problem domain*

### Generated files

```
outputs/generated_solution/
├── orchestrator.py       # Main LangGraph workflow orchestrator
├── agents.py             # All agent implementations
├── tools.py              # Tool definitions
├── state_schema.py       # TypedDict state management
├── evaluation.py         # DeepEval test framework
├── requirements.txt      # Dependencies
├── .env.example          # Environment template
└── README.md            # Setup instructions
```

### Run

```bash
cd src
python code_generator_agent.py
```

**Prerequisites:** Run `hackathon_agent.py` first to generate requirements specification.

### Use the generated solution

```bash
cd outputs/generated_solution
cp .env.example .env
# Edit .env with your API keys
pip install -r requirements.txt
python orchestrator.py
```

### Evaluate with DeepEval

```bash
cd outputs/generated_solution
python evaluation.py
```

This runs automated tests measuring:
- Answer relevancy and correctness
- Faithfulness to source data
- Context relevance
- Hallucination detection
- Response latency

---

## Recommended Hackathon Workflow

```
Day 0 (today)
  └── Setup environment, configure .env, verify all three scripts run

Day 1 (problem drop)
  ├── Paste problem statement and deliverables into src/inputs/
  ├── Run hackathon_agent.py → review all 10 outputs
  ├── Add domain URLs from output 05 into SCRAPE_URLS in .env
  ├── Drop any provided PDFs into src/data/
  └── Run ingestion_rag.py to build domain-specific vector store

Day 2 (build)
  ├── Run code_generator_agent.py to generate complete multi-agent solution
  ├── Run presentation_generator.py to create presentation.html
  ├── Review and customize generated code in outputs/generated_solution/
  ├── Test the orchestrator and agent workflows
  └── Use synthetic data outputs for demo if live data is unavailable

Day 3 (present)
  ├── Open outputs/presentation.html in browser for your pitch
  ├── Use output 08 USP for your opening pitch
  ├── Use output 07 AI vs non-AI comparison for the business case slide
  └── Use output 04 competitor landscape for market positioning slide
```
