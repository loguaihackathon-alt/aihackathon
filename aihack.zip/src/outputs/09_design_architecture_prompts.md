```markdown
# 1. ARCHITECTURE PROMPT
```
You are an expert AI system architect. Based on the following problem statement and deliverables, generate a detailed system architecture description for a hackathon solution. Break down the architecture into key components and layers, describing their roles, technologies, and how they interact.

Problem Statement:
Healthcare providers struggle to manage and extract actionable insights from unstructured patient records, clinical notes, and medical literature. Clinicians spend excessive time manually reviewing documents, leading to delayed diagnoses and inconsistent treatment decisions.

Deliverables:
1. A working prototype that ingests unstructured clinical documents.
2. An AI-powered query interface for clinicians to ask natural language questions.
3. A dashboard showing extracted insights, trends, and risk flags.
4. A presentation deck covering solution architecture, USP, and business impact.

Please provide:
- A high-level system architecture diagram description (textual, suitable for visualization).
- Description of each component (e.g., data ingestion, NLP processing, knowledge base, query interface, dashboard).
- Technologies or frameworks recommended for each component.
- Data flow and integration points.
- Considerations for scalability, security, and usability.

Make sure the description is clear enough for a technical team to implement the prototype.

```

```markdown
# 2. CODE GENERATION PROMPT
```
You are a senior AI architect and lead developer tasked with creating the core implementation scaffold for a hackathon project based on the following problem statement and deliverables.

Problem Statement:
Healthcare providers struggle to manage and extract actionable insights from unstructured patient records, clinical notes, and medical literature. Clinicians spend excessive time manually reviewing documents, leading to delayed diagnoses and inconsistent treatment decisions.

Deliverables:
1. A working prototype that ingests unstructured clinical documents.
2. An AI-powered query interface for clinicians to ask natural language questions.
3. A dashboard showing extracted insights, trends, and risk flags.
4. A presentation deck covering solution architecture, USP, and business impact.

Please generate:
- Suggested tech stack (backend, frontend, AI/ML libraries, databases, cloud services).
- A recommended folder structure with brief descriptions of key modules/folders.
- Skeleton code snippets or file templates for the main components: document ingestion, NLP pipeline, query interface backend, dashboard frontend.
- Key interfaces or API contracts between components.
- Tips for modularity and maintainability.

Ensure the scaffold is production-oriented yet suitable for a hackathon timeline.

```

```markdown
# 3. PRESENTATION PROMPT
```
You are an experienced hackathon coach preparing a compelling pitch deck outline for a healthcare AI solution. Based on the problem statement and deliverables below, generate a detailed slide-by-slide outline for a 7-10 minute presentation including talking points and demo flow.

Problem Statement:
Healthcare providers struggle to manage and extract actionable insights from unstructured patient records, clinical notes, and medical literature. Clinicians spend excessive time manually reviewing documents, leading to delayed diagnoses and inconsistent treatment decisions.

Deliverables:
1. A working prototype that ingests unstructured clinical documents.
2. An AI-powered query interface for clinicians to ask natural language questions.
3. A dashboard showing extracted insights, trends, and risk flags.
4. A presentation deck covering solution architecture, USP, and business impact.

Please provide:
- Slide titles with brief descriptions.
- Key talking points per slide.
- Suggested visuals or diagrams.
- Demo flow and key features to showcase live.
- Tips on emphasizing USP and business impact.

Make sure the outline is structured to tell a clear, compelling story and keep judges engaged.

```

```markdown
# 4. DEMO SCRIPT PROMPT
```
You are a hackathon team lead preparing a live demo walkthrough script for judges. The solution addresses the following problem and deliverables.

Problem Statement:
Healthcare providers struggle to manage and extract actionable insights from unstructured patient records, clinical notes, and medical literature. Clinicians spend excessive time manually reviewing documents, leading to delayed diagnoses and inconsistent treatment decisions.

Deliverables:
1. A working prototype that ingests unstructured clinical documents.
2. An AI-powered query interface for clinicians to ask natural language questions.
3. A dashboard showing extracted insights, trends, and risk flags.
4. A presentation deck covering solution architecture, USP, and business impact.

Please generate a detailed demo script that includes:
- Introduction and context setting.
- Step-by-step walkthrough of key features (document ingestion, query interface usage, dashboard exploration).
- Example user queries and AI responses.
- Highlighting unique selling points and technical strengths during the demo.
- Suggested transitions and timing cues for a 7-10 minute demo session.
- How to handle potential questions or issues live.

Make sure the script is engaging, clear, and showcases the solution’s impact effectively.

```