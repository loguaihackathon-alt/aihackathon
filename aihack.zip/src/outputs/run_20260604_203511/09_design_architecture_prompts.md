```markdown
# 1. ARCHITECTURE PROMPT
```
You are an expert AI system architect. Generate a detailed system architecture description and component breakdown for an end-to-end AI-powered insurance claims processing platform. The system should include:

- Multi-agent architecture with specific agents: Document Parser Agent, Validation Agent, Fraud Detection Agent, Decision Agent, and Customer Communication Agent.
- Automated multi-modal document ingestion supporting PDFs, scanned images, and handwritten forms using OCR and handwriting recognition.
- Use of Large Language Models (LLMs) fine-tuned on insurance domain data.
- Integration of Retrieval-Augmented Generation (RAG) to dynamically access external knowledge bases such as policy documents, regulatory guidelines, and historical claims.
- Workflow orchestration coordinating agent interactions and data flow.
- Real-time claim status dashboard for customers and internal users.
- Data storage components: structured claim database, document repository, fraud pattern database, and logs.
- API layer exposing services for frontend and external integrations.
- Security and compliance considerations.
- Deployment model suggestions (cloud-native, containerized microservices).

Describe each component’s role, key technologies or frameworks to use, and how components interact. Provide a high-level data flow and control flow overview. Include scalability and fault tolerance considerations.

---

```markdown
# 2. CODE GENERATION PROMPT
```
You are a senior AI architect tasked with generating a core implementation scaffold for a hackathon AI insurance claims processing system. Generate a detailed project scaffold including:

- Recommended tech stack for backend (e.g., Python, FastAPI), frontend (e.g., React.js), AI/ML components (e.g., Hugging Face transformers, PyTorch/TensorFlow), OCR and handwriting recognition tools, database (e.g., PostgreSQL, MongoDB), and message queues or orchestration (e.g., RabbitMQ, Celery).
- Suggested folder and module structure, separating agents (Document Parser, Validation, Fraud Detection, Decision, Customer Communication), common utilities, data processing pipelines, model serving, API services, and frontend.
- Stub files or module outlines with brief docstrings describing purpose.
- Integration points for LLMs and RAG pipelines.
- Basic configuration files and environment setup notes.
- Testing framework and sample test case placeholders.
- Containerization approach (e.g., Dockerfile outline).

The scaffold should enable rapid prototyping and modular development by multiple teams.

---

```markdown
# 3. PRESENTATION PROMPT
```
You are preparing a compelling 10-12 slide hackathon pitch deck for a next-gen AI-powered insurance claims processing solution. Generate a detailed outline with slide titles and key talking points for each slide, including:

1. Problem Statement: Market size, challenges of manual claims processing, fraud, and customer pain points.
2. Market Opportunity: Industry impact, cost savings, and competitive landscape.
3. Solution Overview: High-level description of the AI-powered platform and USP.
4. Technical Architecture: Multi-agent system, LLMs, RAG, workflows.
5. Agent Roles & Workflows: Responsibilities and interactions of each agent.
6. Demo Walkthrough: Key demo features and user flow.
7. Business Impact: Projected processing time reduction, cost savings, fraud detection improvements, customer satisfaction.
8. Competitive Analysis: Differentiators vs existing solutions.
9. Implementation Roadmap: MVP, scaling, future enhancements.
10. Team & Ask: Team expertise and resources needed.
11. Q&A / Closing.

Include suggested visuals or diagrams per slide and tips for impactful storytelling and engagement with judges.

---

```markdown
# 4. DEMO SCRIPT PROMPT
```
You are designing a live demo walkthrough script for judges showcasing an AI-powered insurance claims processing platform. Generate a step-by-step demo script covering:

- End-to-end claim submission: user uploads multi-modal documents (PDF, photos, handwritten forms).
- Real-time automated data extraction by Document Parser Agent with example outputs.
- Validation Agent cross-referencing claim data with policy and external data sources using RAG.
- Fraud Detection Agent identifying suspicious patterns with explanation.
- Decision Agent recommending claim approval or rejection with transparent reasoning.
- Customer Communication Agent generating real-time status updates via chatbot or dashboard.
- Display of processing time improvements compared to manual baseline.
- Highlight how explainability and consistency are achieved.
- Interaction with judges through Q&A prompts or “what-if” scenario adjustments.
- Summary of business impact and next steps.

Include timing cues, key phrases to emphasize, and fallback points in case of demo issues.
```