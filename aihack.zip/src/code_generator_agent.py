import os
import urllib3
import httpx
from datetime import datetime
from dotenv import load_dotenv
from typing import TypedDict, Literal
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY   = os.getenv("GENAI_API_KEY")
BASE_URL  = os.getenv("GENAI_BASE_URL")
LLM_MODEL = os.getenv("GENAI_LLM_MODEL")

custom_http_client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=BASE_URL,
    model=LLM_MODEL,
    api_key=API_KEY,
    http_client=custom_http_client,
    temperature=0.7,
    max_tokens=16000
)

INPUTS_DIR  = os.path.join(os.path.dirname(__file__), "inputs")
OUTPUTS_BASE_DIR = os.path.join(os.path.dirname(__file__), "outputs")

def find_latest_run_dir() -> str:
    """Find the most recent run_* directory."""
    if not os.path.exists(OUTPUTS_BASE_DIR):
        raise FileNotFoundError(f"Outputs directory not found: {OUTPUTS_BASE_DIR}")
    
    run_dirs = [d for d in os.listdir(OUTPUTS_BASE_DIR) if d.startswith("run_") and os.path.isdir(os.path.join(OUTPUTS_BASE_DIR, d))]
    if not run_dirs:
        raise FileNotFoundError("No run directories found. Run hackathon_agent.py first.")
    
    run_dirs.sort(reverse=True)
    return os.path.join(OUTPUTS_BASE_DIR, run_dirs[0])

# Create timestamped solution folder inside latest run directory
RUN_TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
try:
    latest_run = find_latest_run_dir()
    CODE_OUTPUT_DIR = os.path.join(latest_run, f"generated_solution_{RUN_TIMESTAMP}")
except:
    # Fallback if no run directory exists
    CODE_OUTPUT_DIR = os.path.join(OUTPUTS_BASE_DIR, f"generated_solution_{RUN_TIMESTAMP}")

def read_input(filename: str) -> str:
    path = os.path.join(INPUTS_DIR, filename)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return ""

def read_output(filename: str) -> str:
    try:
        run_dir = find_latest_run_dir()
        path = os.path.join(run_dir, filename)
    except:
        path = os.path.join(OUTPUTS_BASE_DIR, filename)
    
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return ""

def write_code_file(filepath: str, content: str):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    rel_path = os.path.relpath(filepath, OUTPUTS_DIR)
    print(f"  [generated] {rel_path}")

def invoke(prompt: str) -> str:
    return llm.invoke(prompt).content.strip()

# ── State ─────────────────────────────────────────────────────────────────────

class CodeGenState(TypedDict):
    problem: str
    deliverables: str
    usp: str
    requirements: str
    synthetic_format: str
    agent_architecture: str
    agents_list: list[dict]
    orchestrator_code: str
    agent_codes: dict
    tools_code: str
    state_schema: str
    evaluation_code: str
    readme: str

# ── Nodes ─────────────────────────────────────────────────────────────────────

def load_context(state: CodeGenState) -> CodeGenState:
    print("[1/9] Loading problem context...")
    
    # Check for synthetic data format
    synthetic_format = "csv"
    try:
        run_dir = find_latest_run_dir()
        if not os.path.exists(os.path.join(run_dir, "01_synthetic_data_low.csv")):
            synthetic_format = "txt"
    except:
        pass
    
    return {
        **state,
        "problem": read_input("problem_statement.txt"),
        "deliverables": read_input("deliverables.txt"),
        "usp": read_output("08_usp_analysis.md")[:800],
        "requirements": read_output("06_requirements_specification.md")[:1000],
        "synthetic_format": synthetic_format
    }


def design_agent_architecture(state: CodeGenState) -> CodeGenState:
    print("[2/9] Designing agent architecture...")
    prompt = f"""You are a senior AI solutions architect specializing in multi-agent systems.

Problem Statement:
{state['problem']}

Deliverables:
{state['deliverables']}

Requirements Summary:
{state['requirements'][:600]}

Design a complete multi-agent orchestration architecture for this problem. Your design MUST include:

1. ORCHESTRATOR AGENT
   - Central coordinator managing workflow
   - State management and agent coordination
   - Error handling and recovery

2. CORE AGENTS (identify 4-6 agents based on problem complexity):
   Examples: Planner, Researcher, DataProcessor, Analyzer, Reviewer, ActionPerformer, Evaluator
   
   For EACH agent, specify:
   - Agent name and role
   - Specific responsibilities
   - Tools/capabilities it needs
   - When it should be invoked in the workflow

3. WORKFLOW DEFINITION
   - Sequential or conditional agent execution flow
   - Decision points and routing logic
   - State passed between agents

Output format (JSON):
{{
  "architecture_summary": "Brief overview of the multi-agent system design",
  "agents": [
    {{
      "name": "PlannerAgent",
      "role": "Creates execution plan based on user query",
      "responsibilities": ["Break down complex queries", "Define execution steps"],
      "tools": ["query_parser", "knowledge_base_search"],
      "trigger_condition": "Always runs first after orchestrator"
    }}
  ],
  "workflow": "Detailed description of agent execution flow with decision points"
}}
"""
    result = invoke(prompt)
    return {**state, "agent_architecture": result}


def extract_agents_list(state: CodeGenState) -> CodeGenState:
    print("[3/9] Extracting agent specifications...")
    import json
    try:
        arch_data = json.loads(state["agent_architecture"])
        agents = arch_data.get("agents", [])
    except:
        agents = []
    return {**state, "agents_list": agents}


def generate_state_schema(state: CodeGenState) -> CodeGenState:
    print("[4/9] Generating state schema...")
    agents_summary = "\n".join([f"- {a['name']}: {a['role']}" for a in state["agents_list"]])
    
    prompt = f"""Generate a Python TypedDict state schema for a LangGraph multi-agent system.

Agents in the system:
{agents_summary}

The state should include:
- User query/input
- Intermediate results from each agent
- Final output
- Error tracking
- Metadata (timestamps, step count)

Generate ONLY the Python code for the state class. Include necessary imports."""
    
    result = invoke(prompt)
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "state_schema.py"), result)
    return {**state, "state_schema": result}


def generate_tools(state: CodeGenState) -> CodeGenState:
    print("[5/9] Generating tool implementations...")
    
    all_tools = set()
    for agent in state["agents_list"]:
        all_tools.update(agent.get("tools", []))
    
    prompt = f"""You are generating tool implementations for a multi-agent RAG system.

Problem Context:
{state['problem'][:400]}

Required Tools:
{', '.join(all_tools)}

Generate Python code with @tool decorators for each tool. Include:
- RAG query tool (uses vector store)
- Data processing tools
- Analysis/computation tools
- External API call tools (if needed)

Use this pattern:
```python
from langchain_core.tools import tool

@tool
def tool_name(param: str) -> str:
    \"\"\"Tool description.\"\"\"
    # Implementation
    return result
```

Include proper error handling. Generate ONLY the Python code."""
    
    result = invoke(prompt)
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "tools.py"), result)
    return {**state, "tools_code": result}


def generate_agent_nodes(state: CodeGenState) -> CodeGenState:
    print("[6/9] Generating agent node implementations...")
    agent_codes = {}
    
    for idx, agent in enumerate(state["agents_list"], 1):
        print(f"  [6/{9}] Generating {agent['name']}...")
        prompt = f"""Generate a Python function for this agent node in a LangGraph workflow.

Agent Specification:
Name: {agent['name']}
Role: {agent['role']}
Responsibilities: {', '.join(agent.get('responsibilities', []))}
Tools Available: {', '.join(agent.get('tools', []))}

The function signature should be:
def {agent['name'].lower().replace('agent', '_agent')}(state: MultiAgentState) -> dict:
    # Implementation
    return {{"key": "updated_value"}}

Requirements:
- Read relevant data from state
- Use LLM to perform agent's task
- Optionally call tools if needed
- Update and return state dict
- Include error handling

Generate ONLY the Python function code with necessary imports."""
        
        result = invoke(prompt)
        agent_codes[agent['name']] = result
    
    # Combine all agent functions into one file
    all_agents_code = "# Agent Node Implementations\n\n"
    all_agents_code += "from typing import Dict, Any\n"
    all_agents_code += "from langchain_openai import ChatOpenAI\n"
    all_agents_code += "from state_schema import MultiAgentState\n"
    all_agents_code += "from tools import *\n\n"
    all_agents_code += "\n\n".join(agent_codes.values())
    
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "agents.py"), all_agents_code)
    return {**state, "agent_codes": agent_codes}


def generate_orchestrator(state: CodeGenState) -> CodeGenState:
    print("[7/9] Generating orchestrator and graph...")
    
    agents_names = [a['name'] for a in state['agents_list']]
    workflow_desc = state['agent_architecture']
    
    prompt = f"""Generate a complete LangGraph orchestrator for a multi-agent system.

Agents:
{', '.join(agents_names)}

Workflow Description:
{workflow_desc[:800]}

Generate Python code that:
1. Imports all agents from agents.py
2. Imports state schema
3. Creates StateGraph
4. Adds all agent nodes
5. Defines edges (sequential or conditional)
6. Includes conditional routing if needed
7. Compiles the graph
8. Has a main() function that runs the workflow

Use this structure:
```python
from langgraph.graph import StateGraph, START, END
from state_schema import MultiAgentState
from agents import *

def create_workflow():
    graph = StateGraph(MultiAgentState)
    # Add nodes
    # Add edges
    return graph.compile()

if __name__ == "__main__":
    workflow = create_workflow()
    result = workflow.invoke(initial_state)
```

Generate ONLY the complete Python code."""
    
    result = invoke(prompt)
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "orchestrator.py"), result)
    return {**state, "orchestrator_code": result}


def generate_evaluation_framework(state: CodeGenState) -> CodeGenState:
    print("[8/9] Generating evaluation framework with DeepEval...")
    
    prompt = f"""Generate a DeepEval-based evaluation framework for this multi-agent system.

Problem Context:
{state['problem'][:400]}

Generate Python code that:
1. Imports deepeval metrics (Correctness, Faithfulness, ContextualRelevancy, Hallucination, Latency)
2. Creates test cases for the multi-agent system
3. Defines evaluation metrics
4. Runs evaluation and generates report

Include:
- Sample test cases (at least 3)
- Metric definitions
- Evaluation runner
- Results reporting

Use this pattern:
```python
from deepeval import evaluate
from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric, HallucinationMetric
from deepeval.test_case import LLMTestCase

# Test cases
# Metrics
# Evaluation
```

Generate ONLY the complete Python code."""
    
    result = invoke(prompt)
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "evaluation.py"), result)
    return {**state, "evaluation_code": result}


def generate_readme_and_structure(state: CodeGenState) -> CodeGenState:
    print("[9/9] Generating README and supporting files...")
    
    # Generate requirements.txt
    requirements = """# Multi-Agent Solution Dependencies
langchain>=0.3.0
langchain-openai>=0.3.0
langgraph>=0.1.0
llama-index-core>=0.11.0
deepeval>=1.0.0
python-dotenv>=1.0.1
httpx>=0.27.0
faiss-cpu>=1.8.0
"""
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "requirements.txt"), requirements)
    
    # Generate .env template
    env_template = """# LLM Configuration
GENAI_API_KEY=your-api-key
GENAI_BASE_URL=https://your-gateway/v1
GENAI_LLM_MODEL=your-model-name
GENAI_EMBEDDING_MODEL=your-embedding-model
"""
    write_code_file(os.path.join(CODE_OUTPUT_DIR, ".env.example"), env_template)
    
    # Generate README
    agents_list = "\n".join([f"- **{a['name']}**: {a['role']}" for a in state['agents_list']])
    
    readme = f"""# Multi-Agent Solution

Auto-generated multi-agent orchestration system for:
{state['problem'][:200]}

## Architecture

### Agents
{agents_list}

### Workflow
The orchestrator coordinates agent execution based on the problem requirements.

## Setup

1. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\\Scripts\\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure environment:
```bash
cp .env.example .env
# Edit .env with your API keys
```

## Usage

Run the orchestrator:
```bash
python orchestrator.py
```

## Evaluation

Run DeepEval tests:
```bash
python evaluation.py
```

## File Structure

```
generated_solution/
├── orchestrator.py       # Main workflow orchestrator
├── agents.py             # All agent implementations
├── tools.py              # Tool definitions
├── state_schema.py       # State management
├── evaluation.py         # DeepEval framework
├── requirements.txt      # Dependencies
└── README.md            # This file
```

## Customization

- Modify agent logic in `agents.py`
- Add new tools in `tools.py`
- Adjust workflow in `orchestrator.py`
- Extend evaluation metrics in `evaluation.py`
"""
    
    write_code_file(os.path.join(CODE_OUTPUT_DIR, "README.md"), readme)
    return {**state, "readme": readme}


# ── Graph Assembly ────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    g = StateGraph(CodeGenState)
    nodes = [
        ("load_context",              load_context),
        ("design_architecture",       design_agent_architecture),
        ("extract_agents",            extract_agents_list),
        ("generate_state",            generate_state_schema),
        ("generate_tools",            generate_tools),
        ("generate_agents",           generate_agent_nodes),
        ("generate_orchestrator",     generate_orchestrator),
        ("generate_evaluation",       generate_evaluation_framework),
        ("generate_readme",           generate_readme_and_structure),
    ]
    
    for name, fn in nodes:
        g.add_node(name, fn)
    
    sequence = [name for name, _ in nodes]
    g.add_edge(START, sequence[0])
    for i in range(len(sequence) - 1):
        g.add_edge(sequence[i], sequence[i + 1])
    g.add_edge(sequence[-1], END)
    
    return g.compile()


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 70)
    print("  DEEP CODE GENERATOR — Multi-Agent Solution Builder")
    print("=" * 70)
    print("\nThis will generate a complete multi-agent orchestration solution")
    print("based on your problem statement and requirements.\n")
    
    # Validate prerequisites
    try:
        run_dir = find_latest_run_dir()
        required_files = [
            os.path.join(INPUTS_DIR, "problem_statement.txt"),
            os.path.join(run_dir, "06_requirements_specification.md")
        ]
    except:
        required_files = [
            os.path.join(INPUTS_DIR, "problem_statement.txt")
        ]
    
    missing = [f for f in required_files if not os.path.exists(f)]
    if missing:
        print("[ERROR] Required files missing:")
        for f in missing:
            print(f"  - {os.path.relpath(f, os.path.dirname(__file__))}")
        print("\nRun hackathon_agent.py first to generate requirements.")
        exit(1)
    
    agent = build_graph()
    
    initial_state = {
        "problem": "", "deliverables": "", "usp": "", "requirements": "",
        "synthetic_format": "csv", "agent_architecture": "",
        "agents_list": [], "orchestrator_code": "", "agent_codes": {},
        "tools_code": "", "state_schema": "", "evaluation_code": "", "readme": ""
    }
    
    from datetime import datetime
    start = datetime.now()
    
    final_state = agent.invoke(initial_state)
    
    elapsed = (datetime.now() - start).seconds
    
    print(f"\n{'=' * 70}")
    print(f"  COMPLETE — Solution generated in {elapsed}s")
    print(f"{'=' * 70}")
    print(f"\nGenerated files location: {os.path.relpath(CODE_OUTPUT_DIR, os.path.dirname(__file__))}")
    print("\nNext steps:")
    print(f"  1. cd {os.path.relpath(CODE_OUTPUT_DIR, os.path.dirname(__file__))}")
    print("  2. Review the generated code")
    print("  3. Configure .env with your API keys")
    print("  4. pip install -r requirements.txt")
    print("  5. python orchestrator.py")
