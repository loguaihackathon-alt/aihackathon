import os
import urllib3
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY   = os.getenv("GENAI_API_KEY")
BASE_URL  = os.getenv("GENAI_BASE_URL")
LLM_MODEL = os.getenv("GENAI_LLM_MODEL")

custom_http_client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=BASE_URL,
    model=LLM_MODEL,
    api_key=API_KEY,
    http_client=custom_http_client,
    temperature=0.7,
    max_tokens=16000
)

OUTPUTS_BASE_DIR = os.path.join(os.path.dirname(__file__), "outputs")

def find_latest_run_dir() -> str:
    """Find the most recent run_* directory."""
    if not os.path.exists(OUTPUTS_BASE_DIR):
        raise FileNotFoundError(f"Outputs directory not found: {OUTPUTS_BASE_DIR}")
    
    run_dirs = [d for d in os.listdir(OUTPUTS_BASE_DIR) if d.startswith("run_") and os.path.isdir(os.path.join(OUTPUTS_BASE_DIR, d))]
    if not run_dirs:
        raise FileNotFoundError("No run directories found. Run hackathon_agent.py first.")
    
    # Sort by timestamp (embedded in folder name)
    run_dirs.sort(reverse=True)
    return os.path.join(OUTPUTS_BASE_DIR, run_dirs[0])

def read_presentation_prompt() -> str:
    run_dir = find_latest_run_dir()
    path = os.path.join(run_dir, "10_presentation_html_video_prompt.md")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Presentation prompt not found at {path}\n"
            "Run hackathon_agent.py first to generate the prompt."
        )
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

def generate_html_presentation(prompt_content: str) -> str:
    print("Generating HTML presentation from prompt...")
    print("This may take 60-90 seconds due to large output...")
    
    # Extract the actual prompt from the markdown code block if wrapped
    lines = prompt_content.splitlines()
    if lines[0].startswith("```"):
        lines = lines[1:]
    if lines[-1].startswith("```"):
        lines = lines[:-1]
    prompt_text = "\n".join(lines)
    
    # Enhanced prompt with specific formatting instructions
    enhanced_prompt = f"""{prompt_text}

IMPORTANT FORMATTING REQUIREMENTS:

1. CREATE A TABBED INTERFACE:
   - Use HTML tabs/navigation with 7 clickable tab buttons at the top
   - Each tab corresponds to one slide (Business Challenge, Solution, Architecture, etc.)
   - Only one tab content visible at a time using CSS display properties
   - Active tab should be highlighted with distinct styling
   - Include Previous/Next navigation buttons within each tab

2. ENHANCE DIAGRAMS AND VISUALS:
   - For Architecture diagram: Use CSS Grid or Flexbox to create layered boxes representing components
   - For Agent workflow: Use CSS to create connected boxes with arrows (using ::after pseudo-elements or SVG)
   - For metrics/KPIs: Create visual gauge/progress bars using CSS
   - For comparison charts: Use CSS bar charts or table with colored backgrounds
   - Include icons using Unicode symbols or CSS shapes (e.g., ⚙️, 📊, 🔍, 💡, ✓)
   
3. USE MODERN CSS STYLING:
   - Implement CSS variables for consistent theming
   - Add smooth transitions between tabs
   - Use CSS Grid for layout within each tab
   - Add box shadows, gradients, and modern UI patterns
   - Make it fully responsive

4. EXAMPLE TAB STRUCTURE:
```html
<div class="tabs-container">
  <div class="tab-buttons">
    <button class="tab-btn active" data-tab="tab1">Business Challenge</button>
    <button class="tab-btn" data-tab="tab2">Solution</button>
    <!-- ... more tabs -->
  </div>
  <div class="tab-content active" id="tab1">
    <!-- Content here -->
    <div class="nav-buttons">
      <button class="prev-btn" disabled>Previous</button>
      <button class="next-btn">Next</button>
    </div>
  </div>
  <!-- More tab contents -->
</div>
```

5. INCLUDE JAVASCRIPT:
   - Add inline JavaScript for tab switching
   - Implement Previous/Next navigation
   - Add keyboard navigation (arrow keys)

Generate the COMPLETE HTML file with all CSS and JavaScript inline."""
    
    response = llm.invoke(enhanced_prompt)
    return response.content.strip()

def save_html(content: str):
    run_dir = find_latest_run_dir()
    path = os.path.join(run_dir, "presentation.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"\n[OK] HTML presentation saved to: {path}")
    print(f"     Open it in a browser to view the presentation")

if __name__ == "__main__":
    print("=" * 60)
    print("  PRESENTATION GENERATOR")
    print("=" * 60)
    
    try:
        prompt = read_presentation_prompt()
        html = generate_html_presentation(prompt)
        save_html(html)
        
        print("\n" + "=" * 60)
        print("  DONE")
        print("=" * 60)
    except FileNotFoundError as e:
        print(f"\n[ERROR] {e}")
    except Exception as e:
        print(f"\n[ERROR] Failed to generate presentation: {e}")
