```markdown
# 1. ARCHITECTURE PROMPT
```
You are an expert AI solution architect. Please generate a detailed system architecture diagram description and component breakdown for an "AI-Driven Resource Capacity Optimization" platform tailored to a large enterprise technology organization managing 250+ resources across multiple teams. The system should:

- Ingest diverse data formats (spreadsheets, PDFs, emails, reports) related to resource skills, allocations, utilization, projects, and workload.
- Employ Large Language Models (LLMs) and Retrieval-Augmented Generation (RAG) for semantic parsing and structured data extraction from unstructured documents.
- Implement a multi-agent architecture comprising:
  - Document Parser Agent to extract and normalize data.
  - Validation Agent to cross-check and validate resource allocation data.
  - Decision Agent to recommend resource rebalancing, redeployment, and prioritization.
  - Customer Communication Agent to generate status updates and reports.
- Include a real-time dashboard showing capacity utilization, skill availability, and risk analysis.
- Support continuous learning and feedback loops to improve extraction accuracy and decision quality.
- Provide API endpoints for integration with existing enterprise systems (HRMS, project management, time tracking).
- Visualize resource demand forecasting and risk analysis.
- Ensure scalability, security, and data privacy compliance.

Please break down the system into key components, describe their roles, interactions, data flow, and suggest appropriate technologies or frameworks that align with modern cloud-native AI architectures.

---

# 2. CODE GENERATION PROMPT
```
You are a senior software engineer tasked with generating the core implementation scaffold for an AI-driven resource capacity optimization platform. Please provide:

- A recommended tech stack suitable for building a scalable, modular, cloud-native AI platform with data ingestion, multi-agent orchestration, and real-time dashboards. Include backend, frontend, AI/ML frameworks, databases, and messaging layers.
- A suggested folder structure that clearly separates concerns such as data ingestion, AI agents, business logic, APIs, frontend dashboard, and utilities.
- Key modules and their responsibilities, including but not limited to:
  - Data ingestion and preprocessing
  - LLM integration and RAG pipeline
  - Multi-agent orchestration and inter-agent communication
  - Validation and decision-making engines
  - Reporting and communication generation
  - Real-time dashboard backend and frontend components
- Include brief code snippets or pseudocode stubs for initializing core modules and agent workflows.
- Mention considerations for containerization, CI/CD pipeline, and deployment strategy.

Provide the scaffold as a clear, ready-to-extend codebase outline suitable for hackathon implementation.

---

# 3. PRESENTATION PROMPT
```
You are a hackathon team lead preparing a compelling pitch deck outline for an AI-driven resource capacity optimization solution targeting enterprise delivery operations. Please generate:

- A slide-by-slide outline with recommended slide titles and key bullet points.
- Talking points for each slide emphasizing business impact, technical innovation, and solution benefits.
- A demo flow highlighting the prototype’s core features: document ingestion, multi-agent validation and decision-making, real-time capacity dashboard, and risk analysis.
- A brief summary slide with future roadmap, scalability potential, and call-to-action for leadership.
- Tips to engage judges by addressing problem context, solution uniqueness, and measurable outcomes.

The pitch deck should be structured for a 10-15 minute presentation with clear transitions and memorable takeaways.

---

# 4. DEMO SCRIPT PROMPT
```
You are a product demo specialist preparing a live walkthrough script for judges at an AI hackathon. The demo is for an AI-driven resource capacity optimization platform designed for a large enterprise with 250+ resources.

Please generate a detailed, step-by-step demo walkthrough script that:

- Opens with a brief problem statement and solution overview.
- Demonstrates uploading and automatic ingestion of diverse resource data (e.g., PDFs, spreadsheets).
- Shows how the Document Parser Agent extracts structured data and normalizes it.
- Illustrates the Validation Agent cross-referencing data to identify inconsistencies or errors.
- Walks through the Decision Agent recommending resource reassignments, highlighting reasoning and priority logic.
- Presents the real-time capacity visualization dashboard displaying utilization levels, skill shortages, and risk areas.
- Explains how Customer Communication Agent creates clear status updates and reports.
- Includes a scenario showing how the system dynamically adapts to new incoming data and updates recommendations.
- Concludes with a summary of benefits and how the solution addresses the enterprise challenges.

The script should include clear user actions, expected system responses, and suggested talking points to engage judges effectively.
```