```markdown
Generate a professional, engaging, and data-driven HTML presentation or video script on **AI-Driven Resource Capacity Optimization for Enterprise Delivery Operations**. The content should be structured into seven distinct slides/scenes covering business challenges, solution overview, technical details, agent roles, outcomes, evaluation, and demo flow.

---

# Presentation / Video Script Generation Prompt

## General Instructions
- Format:  
  - For HTML: Use semantic HTML5 structure with `<section>` for each slide, `<h1>`, `<h2>`, `<p>`, `<ul>`, `<li>`, `<figure>`, and `<figcaption>` where appropriate.  
  - Apply modern, clean CSS styling: consistent color palette (blues, grays), readable fonts (e.g., Roboto or Open Sans), subtle shadows and transitions for emphasis.  
  - Include placeholders or suggestions for visuals such as charts, icons, architecture diagrams, and flow animations.  
- Tone: Professional, authoritative, clear, and engaging with data-driven storytelling.  
- Use real-world enterprise context and sample statistics where relevant.  
- Text content must be concise but thorough, supporting visuals.  
- For video script: Include scene descriptions, on-screen text, voiceover narration, and visual cues.

---

## Slide/Scene 1: BUSINESS CHALLENGE

### Content Requirements:
- Clear and compelling problem statement describing resource capacity challenges in a large enterprise technology organization managing 250+ resources across multiple specialized teams.
- Real-world impact examples: burnout risks, delayed deliveries, skill bottlenecks, uneven workload distribution.
- Industry statistics and market data points such as:  
  - % of teams operating above 120% capacity  
  - Attrition rates linked to overwork (e.g., +15% increase)  
  - % underutilization in dev/QA teams (e.g., 30% below 70% utilization)  
- List of major pain points and inefficiencies:  
  - Over-allocation in cloud engineering and cybersecurity (120%-145%)  
  - Skill concentration risks causing single points of failure  
  - Production support workload spikes causing SLA misses  
  - Lack of proactive capacity forecasting

### Visual Suggestions:
- Bar chart showing current utilization by team  
- Infographic illustrating skill bottlenecks and burnout risks  
- Icons representing major pain points

---

## Slide/Scene 2: SOLUTION OVERVIEW

### Content Requirements:
- What the AI-Driven Resource Capacity Optimization solution aims to solve: balanced workload, skill gap mitigation, predictive capacity planning, operational stability.
- Key feature outcomes & benefits:  
  - Real-time adaptive capacity insights  
  - Automated multi-format data ingestion and semantic parsing  
  - Intelligent resource rebalancing recommendations  
  - Cross-skilling and prioritization logic for scarce resources  
  - Improved delivery predictability and SLA compliance
- Target personas:  
  - Delivery/Program Managers  
  - Resource/Workforce Planners  
  - CTO/Engineering Leadership  
  - HR & Talent Management  

### Visual Suggestions:
- High-level solution architecture icon set  
- Benefit-driven callouts with checkmarks  
- Persona icons with role labels

---

## Slide/Scene 3: TECHNICAL ARCHITECTURE

### Content Requirements:
- Describe a Python-based system architecture supporting the solution:  
  - Data ingestion pipelines handling spreadsheets, PDFs, emails  
  - LLM-powered semantic parsing + Retrieval-Augmented Generation (RAG) layer  
  - Agentic AI orchestration with multiple specialized agents  
  - RESTful APIs for integration with existing enterprise tools  
- Explain agentic AI architecture leveraging LLMs for decision making and continuous learning.
- Component breakdown with brief descriptions:  
  - Ingestion Engine  
  - Semantic Parser + RAG Module  
  - Resource & Capacity Model  
  - Planning & Recommendation Agents  
  - API Layer & Dashboard Interface

### Visual Suggestions:
- System diagram with labeled components and data flow arrows  
- Icons representing each component (e.g., database, AI brain, API endpoints)  
- Animated flow showing data transformation from ingestion to recommendation

---

## Slide/Scene 4: AGENT ROLES & RESPONSIBILITIES

### Content Requirements:
- Define each AI agent’s role and responsibilities:  
  - Research Agent: Data gathering, document ingestion, knowledge base updates  
  - Planning Agent: Capacity modeling, scenario simulation, prioritization logic  
  - Execution Agent: Recommendation generation, task assignment suggestions  
  - Monitoring Agent: Continuous usage tracking, anomaly detection, feedback loop  
- Describe agent interaction workflow and collaboration model  
- Explain tool usage (e.g., querying knowledge bases, calling APIs) and decision-making logic

### Visual Suggestions:
- Flowchart depicting agent interactions and data handoff  
- Icons/symbols representing agent functions  
- Example decision tree for prioritization logic

---

## Slide/Scene 5: SOLUTION OUTCOMES & METRICS

### Content Requirements:
- Outline deterministic measurement approach to quantify solution impact  
- Key Performance Indicators (KPIs):  
  - Resource Utilization Balance (%)  
  - Delivery Milestone Adherence Rate (%)  
  - SLA Compliance Rate (%)  
  - Reduction in Overtime Hours (%)  
  - Cross-skilling Adoption Rates  
- Define success criteria and benchmark targets (e.g., reduce over-allocation by 25% within 3 months)

### Visual Suggestions:
- KPI dashboard mockup with gauges and trend lines  
- Before/after utilization comparison graphs  
- Success metric callouts with icons

---

## Slide/Scene 6: EVALUATION FRAMEWORK

### Content Requirements:
- Introduce DeepEval or similar evaluation platform for testing AI agent performance  
- Metrics tracked: accuracy of data extraction, latency of recommendations, hallucination rate, context relevance  
- Describe test case design: synthetic scenarios reflecting real enterprise challenges  
- Outline evaluation pipeline from input data through agent outputs to metric scoring

### Visual Suggestions:
- Pipeline diagram of evaluation flow  
- Metric definition tables or charts  
- Sample test case screenshots or input/output snapshots

---

## Slide/Scene 7: DEMO FLOW

### Content Requirements:
- Step-by-step narrative walkthrough demonstrating solution in action:  
  - Initial state showing unbalanced resource allocation and risks  
  - Data ingestion and AI analysis phases  
  - Agent recommendations for rebalancing and skill cross-training  
  - Final state showing improved utilization and delivery forecasts  
- Before/after comparison emphasizing impact  
- Live interaction example or simulated user query with AI response

### Visual Suggestions:
- Screen mockups or animated UI walkthrough  
- Highlighted text annotations showing key insights  
- Side-by-side comparison charts

---

# Additional Notes

- Include sample data points and realistic statistics throughout to ground the narrative.  
- Use consistent terminology aligned with enterprise delivery and resource management.  
- Provide all text content within HTML elements or video narration script as per format.  
- Suggest icon sets (e.g., material icons, custom SVGs) and chart libraries (e.g., Chart.js) if appropriate.  
- Ensure accessibility considerations such as alt text for images and semantic markup.

---

# End of Prompt
```