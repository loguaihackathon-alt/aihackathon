import os
import csv
import io
import urllib3
import httpx
import requests
from datetime import datetime
from typing import TypedDict, Literal
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY   = os.getenv("GENAI_API_KEY")
BASE_URL  = os.getenv("GENAI_BASE_URL")
LLM_MODEL = os.getenv("GENAI_LLM_MODEL")

custom_http_client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=BASE_URL,
    model=LLM_MODEL,
    api_key=API_KEY,
    http_client=custom_http_client,
    temperature=0.7
)

# ── I/O Helpers ───────────────────────────────────────────────────────────────

INPUTS_DIR  = os.path.join(os.path.dirname(__file__), "inputs")

# Create timestamped folder for this run
RUN_TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUTPUTS_DIR = os.path.join(os.path.dirname(__file__), "outputs", f"run_{RUN_TIMESTAMP}")

def read_input(filename: str) -> str:
    path = os.path.join(INPUTS_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

def write_output(filename: str, content: str):
    os.makedirs(OUTPUTS_DIR, exist_ok=True)
    path = os.path.join(OUTPUTS_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"  [saved] outputs/{filename}")


def markdown_table_to_csv(md_text: str) -> str | None:
    """Extract the first markdown table from text and convert to CSV string."""
    lines = [l.strip() for l in md_text.splitlines()]
    table_lines = [l for l in lines if l.startswith("|") and l.endswith("|")]
    # Filter out separator rows like |---|---|
    table_lines = [l for l in table_lines if not all(c in "-| :" for c in l)]
    if len(table_lines) < 2:
        return None
    buf = io.StringIO()
    writer = csv.writer(buf)
    for row in table_lines:
        cells = [c.strip() for c in row.strip("|").split("|")]
        writer.writerow(cells)
    return buf.getvalue()

def invoke(prompt: str) -> str:
    return llm.invoke(prompt).content.strip()

# ── State ─────────────────────────────────────────────────────────────────────

class HackathonState(TypedDict):
    problem: str
    deliverables: str
    synthetic_format: Literal["csv", "txt"]
    synthetic_low: str
    synthetic_medium: str
    industry_analysis: str
    ai_players: str
    web_research: str
    requirements_spec: str
    ai_vs_non_ai: str
    usp: str
    design_prompts: str
    presentation_prompt: str

# ── Nodes ─────────────────────────────────────────────────────────────────────

def load_inputs(state: HackathonState) -> HackathonState:
    print("[1/10] Loading problem statement and deliverables...")
    return {
        **state,
        "problem": read_input("problem_statement.txt"),
        "deliverables": read_input("deliverables.txt"),
    }


def decide_synthetic_format(state: HackathonState) -> HackathonState:
    print("[2/10] Deciding synthetic data format...")
    prompt = f"""You are a data architect.
Problem Statement:
{state['problem']}

Decide whether synthetic data for this problem is best represented as:
- "csv" — if the solution involves structured/tabular data (transactions, records, logs, sensors, patients, events, etc.)
- "txt" — if the solution involves unstructured data (documents, emails, chat transcripts, reports, narratives, etc.)

Reply with ONLY one word: csv or txt"""
    decision = invoke(prompt).strip().lower()
    fmt: Literal["csv", "txt"] = "csv" if "csv" in decision else "txt"
    print(f"  [format] synthetic data will be saved as .{fmt}")
    return {**state, "synthetic_format": fmt}


def gen_synthetic_low(state: HackathonState) -> HackathonState:
    print("[3/10] Generating synthetic data — low volume...")
    fmt = state["synthetic_format"]

    if fmt == "csv":
        prompt = f"""You are a synthetic data expert.
Problem Statement:
{state['problem']}

Generate a small realistic synthetic dataset of 10-15 records for this problem domain.
Output ONLY a markdown table (no explanation, no extra text) with meaningful column headers and varied realistic values."""
        result = invoke(prompt)
        csv_content = markdown_table_to_csv(result)
        if csv_content:
            write_output("01_synthetic_data_low.csv", csv_content)
        else:
            write_output("01_synthetic_data_low.txt", result)
    else:
        prompt = f"""You are a synthetic data expert.
Problem Statement:
{state['problem']}

Generate 10-15 realistic synthetic text samples (documents, messages, reports, or narratives) relevant to this problem domain.
Each sample should be clearly separated by a blank line and labelled (e.g. Sample 1:, Sample 2:, ...).
Include variety in tone, length, and content to reflect real-world diversity."""
        result = invoke(prompt)
        write_output("01_synthetic_data_low.txt", result)

    return {**state, "synthetic_low": result}


def gen_synthetic_medium(state: HackathonState) -> HackathonState:
    print("[4/10] Generating synthetic data — medium volume...")
    fmt = state["synthetic_format"]

    if fmt == "csv":
        prompt = f"""You are a synthetic data expert.
Problem Statement:
{state['problem']}

Generate a medium synthetic dataset of 40-50 records for this problem domain.
Output ONLY a markdown table (no explanation, no extra text) with meaningful column headers.
Include diverse scenarios, edge cases, and realistic variation across all columns."""
        result = invoke(prompt)
        csv_content = markdown_table_to_csv(result)
        if csv_content:
            write_output("02_synthetic_data_medium.csv", csv_content)
        else:
            write_output("02_synthetic_data_medium.txt", result)
    else:
        prompt = f"""You are a synthetic data expert.
Problem Statement:
{state['problem']}

Generate 40-50 realistic synthetic text samples (documents, messages, reports, or narratives) relevant to this problem domain.
Each sample should be clearly separated by a blank line and labelled (e.g. Sample 1:, Sample 2:, ...).
Include diverse scenarios, edge cases, varying lengths, and realistic language variation."""
        result = invoke(prompt)
        write_output("02_synthetic_data_medium.txt", result)

    return {**state, "synthetic_medium": result}


def gen_industry_analysis(state: HackathonState) -> HackathonState:
    print("[5/10] Generating industry challenges & opportunities...")
    prompt = f"""You are a senior industry analyst.
Problem Statement:
{state['problem']}

Produce a structured analysis covering:
1. Top 5 industry challenges related to this problem (with impact assessment)
2. Top 5 market opportunities this problem creates
3. Regulatory or compliance considerations
4. Market size and growth trends (approximate figures)
5. Key stakeholders affected

Format using markdown headers and bullet points."""
    result = invoke(prompt)
    write_output("03_industry_challenges_opportunities.md", result)
    return {**state, "industry_analysis": result}


def gen_ai_players(state: HackathonState) -> HackathonState:
    print("[6/10] Identifying AI players solving similar problems...")
    prompt = f"""You are a competitive intelligence researcher.
Problem Statement:
{state['problem']}

Identify and describe:
1. Established companies building AI solutions for this problem space (name, approach, product)
2. Notable startups in this space (name, funding stage if known, unique angle)
3. Open-source projects or research initiatives addressing this problem
4. Gaps none of them are fully addressing

Format as structured markdown with a comparison summary table at the end."""
    result = invoke(prompt)
    write_output("04_ai_players_landscape.md", result)
    return {**state, "ai_players": result}


def gen_web_research(state: HackathonState) -> HackathonState:
    print("[7/10] Generating web research summary & crawl targets...")
    prompt = f"""You are a research analyst preparing for a hackathon.
Problem Statement:
{state['problem']}

Produce:
1. A summary of publicly known information about how companies and researchers approach this problem
2. A curated list of 10+ specific URLs (real, likely-existing websites, papers, reports, or docs) 
   worth scraping or reading for deeper context — include why each source is relevant
3. Key themes and narratives found across industry publications
4. Important datasets or benchmarks publicly available for this domain

Format in markdown."""
    result = invoke(prompt)
    write_output("05_web_research_sources.md", result)
    return {**state, "web_research": result}


def gen_requirements_spec(state: HackathonState) -> HackathonState:
    print("[8/10] Generating requirements specification...")
    prompt = f"""You are a senior product manager and AI solutions architect.
Problem Statement:
{state['problem']}

Deliverables:
{state['deliverables']}

Generate a full feature requirements specification including:
1. Functional features leveraging GenAI (LLMs, RAG, agents)
2. Functional features leveraging Agentic AI (multi-agent workflows, tool use, planning)
3. Functional features leveraging ML (classification, prediction, anomaly detection)
4. Non-functional requirements (performance, scalability, security, explainability)
5. User stories for the top 5 features (As a... I want... So that...)

Format as a structured markdown specification document."""
    result = invoke(prompt)
    write_output("06_requirements_specification.md", result)
    return {**state, "requirements_spec": result}


def gen_ai_vs_non_ai(state: HackathonState) -> HackathonState:
    print("[9/10] Generating AI vs non-AI solution comparison...")
    prompt = f"""You are a solutions architect comparing traditional vs AI-powered approaches.
Problem Statement:
{state['problem']}

Requirements Summary:
{state['requirements_spec'][:800]}

For each major feature area, describe:
1. How it would be solved WITHOUT AI (rule-based, manual, traditional software)
   — include effort, limitations, and cost
2. How it is solved WITH AI (LLMs, ML models, agents)
   — include approach, benefits, and trade-offs
3. Quantified improvement estimate (time saved, accuracy gain, cost reduction)

Present as a structured markdown comparison table followed by a narrative summary."""
    result = invoke(prompt)
    write_output("07_ai_vs_non_ai_comparison.md", result)
    return {**state, "ai_vs_non_ai": result}


def gen_usp(state: HackathonState) -> HackathonState:
    print("[10/10] Generating USP analysis...")
    prompt = f"""You are a product strategist and startup advisor.
Problem Statement:
{state['problem']}

Competitor Landscape:
{state['ai_players'][:800]}

Requirements:
{state['requirements_spec'][:600]}

Define the Unique Selling Proposition (USP) for a solution built now:
1. Top 3 differentiators vs existing solutions
2. Why this moment in time is the right time to build this
3. Unfair advantages this solution can have (data, speed, integration, UX)
4. Target customer profile and go-to-market angle
5. One-line pitch and a 3-sentence elevator pitch

Format in markdown."""
    result = invoke(prompt)
    write_output("08_usp_analysis.md", result)
    return {**state, "usp": result}


def gen_design_prompts(state: HackathonState) -> HackathonState:
    print("[11/12] Generating design, architecture & presentation prompts...")
    prompt = f"""You are a senior AI architect and hackathon coach.
Problem Statement:
{state['problem']}

Deliverables:
{state['deliverables']}

USP:
{state['usp'][:600]}

Requirements Summary:
{state['requirements_spec'][:600]}

Generate ready-to-use prompts for the following — each prompt should be detailed enough 
to feed directly into an AI assistant:

1. ARCHITECTURE PROMPT
   A prompt to generate the full system architecture diagram description and component breakdown.

2. CODE GENERATION PROMPT
   A prompt to generate the core implementation scaffold (tech stack, folder structure, key modules).

3. PRESENTATION PROMPT
   A prompt to generate a compelling hackathon pitch deck outline (slides, talking points, demo flow).

4. DEMO SCRIPT PROMPT
   A prompt to generate a live demo walkthrough script for judges.

Separate each with a markdown header and wrap each prompt in a code block."""
    result = invoke(prompt)
    write_output("09_design_architecture_prompts.md", result)
    return {**state, "design_prompts": result}


def gen_presentation_prompt(state: HackathonState) -> HackathonState:
    print("[12/12] Generating HTML/video presentation creation prompt...")
    prompt = f"""You are a presentation and multimedia content expert specializing in technical storytelling.

Context:
Problem Statement:
{state['problem']}

Industry Analysis:
{state['industry_analysis'][:600]}

Requirements:
{state['requirements_spec'][:600]}

USP:
{state['usp'][:500]}

Generate a comprehensive, detailed prompt that can be given to Claude, Gemini, or other AI tools to create an HTML presentation or video script. The prompt should instruct the AI to generate content covering:

1. BUSINESS CHALLENGE SLIDE
   - Problem statement with real-world impact
   - Industry statistics and market data
   - Pain points and current inefficiencies

2. SOLUTION OVERVIEW SLIDE
   - What the solution attempts to solve
   - Key feature outcomes and benefits
   - Target user personas

3. TECHNICAL ARCHITECTURE SLIDE
   - System architecture diagram description (Python-based)
   - Agentic AI architecture with LLMs
   - Component breakdown (data ingestion, RAG, agents, APIs)

4. AGENT ROLES & RESPONSIBILITIES SLIDE
   - What each agent does (Research Agent, Planning Agent, Execution Agent, etc.)
   - Agent interaction workflow
   - Tool usage and decision-making logic

5. SOLUTION OUTCOMES & METRICS SLIDE
   - Deterministic measurement approach
   - Key performance indicators (KPIs)
   - Success criteria and benchmarks

6. EVALUATION FRAMEWORK SLIDE
   - How DeepEval can be used for testing
   - Metrics tracked (accuracy, latency, hallucination rate, context relevance)
   - Test case structure and evaluation pipeline

7. DEMO FLOW SLIDE
   - Step-by-step demo narrative
   - Before/after comparison
   - Live interaction example

The prompt should specify:
- HTML structure with modern CSS styling (or video script format with scene descriptions)
- Visual suggestions (diagrams, icons, charts, animations)
- Tone: professional, engaging, data-driven
- Include sample data points and statistics where relevant

Output the full prompt wrapped in a markdown code block."""
    result = invoke(prompt)
    write_output("10_presentation_html_video_prompt.md", result)
    return {**state, "presentation_prompt": result}

# ── Graph Assembly ────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    g = StateGraph(HackathonState)
    nodes = [
        ("load_inputs",           load_inputs),
        ("decide_synthetic_format", decide_synthetic_format),
        ("synthetic_low",         gen_synthetic_low),
        ("synthetic_medium",      gen_synthetic_medium),
        ("industry_analysis",     gen_industry_analysis),
        ("ai_players",            gen_ai_players),
        ("web_research",          gen_web_research),
        ("requirements_spec",     gen_requirements_spec),
        ("ai_vs_non_ai",          gen_ai_vs_non_ai),
        ("usp",                   gen_usp),
        ("design_prompts",        gen_design_prompts),
        ("presentation_prompt",   gen_presentation_prompt),
    ]
    for name, fn in nodes:
        g.add_node(name, fn)

    # Sequential chain
    sequence = [name for name, _ in nodes]
    g.add_edge(START, sequence[0])
    for i in range(len(sequence) - 1):
        g.add_edge(sequence[i], sequence[i + 1])
    g.add_edge(sequence[-1], END)

    return g.compile()


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  HACKATHON AGENT — OUTPUT GENERATOR")
    print("=" * 60)

    agent = build_graph()
    start = datetime.now()

    final_state = agent.invoke({
        "problem": "", "deliverables": "",
        "synthetic_format": "csv",
        "synthetic_low": "", "synthetic_medium": "",
        "industry_analysis": "", "ai_players": "",
        "web_research": "", "requirements_spec": "",
        "ai_vs_non_ai": "", "usp": "", "design_prompts": "",
        "presentation_prompt": "",
    })

    elapsed = (datetime.now() - start).seconds
    print(f"\n[DONE] All outputs written to {os.path.relpath(OUTPUTS_DIR, os.path.dirname(__file__))} in {elapsed}s")
    print("=" * 60)
