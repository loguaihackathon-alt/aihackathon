import os
import urllib3
import httpx
import requests
import feedparser
from bs4 import BeautifulSoup
from pypdf import PdfReader
from dotenv import load_dotenv
from pydantic import Field
from llama_index.core import Document, Settings, VectorStoreIndex, StorageContext
from llama_index.core.node_parser import TokenTextSplitter
from llama_index.core.embeddings import BaseEmbedding
from llama_index.llms.openai import OpenAI
from llama_index.vector_stores.faiss import FaissVectorStore
import faiss

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

API_KEY        = os.getenv("GENAI_API_KEY")
BASE_URL       = os.getenv("GENAI_BASE_URL")
LLM_MODEL      = os.getenv("GENAI_LLM_MODEL")
EMBEDDING_MODEL = os.getenv("GENAI_EMBEDDING_MODEL")

SCRAPE_URLS       = [u.strip() for u in os.getenv("SCRAPE_URLS", "").split(",") if u.strip()]
WIKIPEDIA_TOPICS  = [t.strip() for t in os.getenv("WIKIPEDIA_TOPICS", "").split(",") if t.strip()]
LOCAL_FILES_DIR   = os.getenv("LOCAL_FILES_DIR", "./data")
RSS_FEEDS         = [u.strip() for u in os.getenv("RSS_FEEDS", "").split(",") if u.strip()]

custom_http_client = httpx.Client(verify=False)

class GatewayEmbedding(BaseEmbedding):
    api_key: str = Field()
    base_url: str = Field()
    model: str = Field()

    def _embed(self, text: str):
        resp = requests.post(
            f"{self.base_url}/embeddings",
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
            json={"model": self.model, "input": text},
            verify=False
        )
        resp.raise_for_status()
        return resp.json()["data"][0]["embedding"]

    def _get_query_embedding(self, query: str): return self._embed(query)
    def _get_text_embedding(self, text: str): return self._embed(text)
    async def _aget_query_embedding(self, query: str): return self._embed(query)

Settings.llm = OpenAI(api_base=BASE_URL, model=LLM_MODEL, api_key=API_KEY, http_client=custom_http_client)
Settings.embed_model = GatewayEmbedding(api_key=API_KEY, base_url=BASE_URL, model=EMBEDDING_MODEL)
Settings.node_parser = TokenTextSplitter(chunk_size=512, chunk_overlap=64)


# ── Source Loaders ────────────────────────────────────────────────────────────

def load_web_pages(urls: list[str]) -> list[Document]:
    docs = []
    for url in urls:
        try:
            resp = requests.get(url, timeout=15, verify=False)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            text = soup.get_text(separator="\n", strip=True)
            docs.append(Document(text=text, metadata={"source": "web", "url": url}))
            print(f"  [web] {url}")
        except Exception as e:
            print(f"  [web] SKIP {url} — {e}")
    return docs


def load_wikipedia(topics: list[str]) -> list[Document]:
    docs = []
    for topic in topics:
        try:
            resp = requests.get(
                "https://en.wikipedia.org/w/api.php",
                params={"action": "query", "titles": topic, "prop": "extracts", "explaintext": True, "format": "json"},
                timeout=15, verify=False
            )
            resp.raise_for_status()
            pages = resp.json()["query"]["pages"]
            page = next(iter(pages.values()))
            if "missing" in page:
                print(f"  [wiki] SKIP '{topic}' — page not found")
                continue
            docs.append(Document(text=page.get("extract", ""), metadata={"source": "wikipedia", "title": topic}))
            print(f"  [wiki] {topic}")
        except Exception as e:
            print(f"  [wiki] SKIP '{topic}' — {e}")
    return docs


def load_local_files(directory: str) -> list[Document]:
    docs = []
    if not os.path.isdir(directory):
        print(f"  [local] SKIP — directory not found: {directory}")
        return docs
    for fname in os.listdir(directory):
        fpath = os.path.join(directory, fname)
        try:
            if fname.endswith(".pdf"):
                reader = PdfReader(fpath)
                text = "\n".join(page.extract_text() or "" for page in reader.pages)
                docs.append(Document(text=text, metadata={"source": "local_pdf", "file": fname}))
            elif fname.endswith(".txt"):
                with open(fpath, "r", encoding="utf-8") as f:
                    text = f.read()
                docs.append(Document(text=text, metadata={"source": "local_txt", "file": fname}))
            else:
                continue
            print(f"  [local] {fname}")
        except Exception as e:
            print(f"  [local] SKIP {fname} — {e}")
    return docs


def load_rss_feeds(feed_urls: list[str]) -> list[Document]:
    docs = []
    for url in feed_urls:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries:
                text = entry.get("summary") or entry.get("title", "")
                if text:
                    docs.append(Document(text=text, metadata={"source": "rss", "feed": url, "title": entry.get("title", "")}))
            print(f"  [rss] {url} — {len(feed.entries)} entries")
        except Exception as e:
            print(f"  [rss] SKIP {url} — {e}")
    return docs


# ── Pipeline ──────────────────────────────────────────────────────────────────

def run_ingestion_pipeline():
    print("Loading documents from external sources...")
    documents = []
    documents += load_local_files(LOCAL_FILES_DIR)
    documents += load_web_pages(SCRAPE_URLS)
    documents += load_wikipedia(WIKIPEDIA_TOPICS)
    documents += load_rss_feeds(RSS_FEEDS)

    if not documents:
        print("No documents loaded — check your .env source configurations.")
        return

    print(f"\n{len(documents)} document(s) loaded. Building FAISS index...")

    faiss_index = faiss.IndexFlatL2(3072)
    storage_context = StorageContext.from_defaults(vector_store=FaissVectorStore(faiss_index=faiss_index))

    index = VectorStoreIndex.from_documents(documents, storage_context=storage_context)

    os.makedirs("./storage_faiss", exist_ok=True)
    index.storage_context.persist(persist_dir="./storage_faiss")
    print("[OK] Vector storage persisted to ./storage_faiss")

if __name__ == "__main__":
    run_ingestion_pipeline()
