﻿from pathlib import Path
import importlib.util

BASE = Path(__file__).resolve().parent.parent
REF_DIR = BASE / "references for code generation"

def _load_module(name: str, filename: str):
    path = REF_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Reference file not found: {path}")
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

try:
    ingestion_rag = _load_module("ingestion_rag", "ingestion_rag.py")
    hackathon_agent = _load_module("hackathon_agent", "hackathon_agent.py")
except Exception as e:
    ingestion_rag = None
    hackathon_agent = None
    __load_error__ = e
