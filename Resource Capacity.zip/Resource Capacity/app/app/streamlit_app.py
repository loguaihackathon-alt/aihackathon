﻿import streamlit as st
import requests
import os
import pandas as pd

# Prefer Streamlit secrets but fall back to environment variable or localhost
API_BASE = None
try:
    API_BASE = st.secrets.get('API_BASE')
except Exception:
    API_BASE = None
API_BASE = API_BASE or os.environ.get('API_BASE', 'http://localhost:8000')

st.title('Resource Capacity - Prototype')

menu = st.sidebar.selectbox('Page', ['Dashboard', 'Ingest', 'Resources', 'Decisions'])

if menu == 'Dashboard':
    st.header('Dashboard')
    st.write('High level KPIs')
    if st.button('Refresh KPIs'):
        try:
            resp = requests.get(f"{API_BASE}/metrics")
            data = resp.json()
            total = data.get('total_resources', 0)
            avg_alloc = data.get('avg_allocation', 0.0)
            st.metric('Total resources', total)
            st.metric('Avg allocation', f"{avg_alloc:.2f}")

            st.subheader('Top Skills')
            skill_counts = data.get('skill_counts', {}) or {}
            if skill_counts:
                srs = pd.Series(skill_counts).sort_values(ascending=False)
                st.bar_chart(srs)
            else:
                st.write('No skill data')

            st.subheader('Team summary')
            team_summary = data.get('team_summary', {}) or {}
            if team_summary:
                df_team = pd.DataFrame.from_dict(team_summary, orient='index')
                st.table(df_team)
            else:
                st.write('No team data')
        except Exception as e:
            st.error(str(e))

elif menu == 'Ingest':
    st.header('Ingestion')
    text = st.text_area('Paste resource documents or CSV here')
    col_a, col_b = st.columns([2,1])
    with col_a:
        if st.button('Analyze'):
            with st.spinner('Calling API...'):
                resp = requests.post(f'{API_BASE}/ingest', json={'text': text})
                st.json(resp.json())
    with col_b:
        if st.button('Run reference ingestion (files)'):
            with st.spinner('Running ingestion pipeline...'):
                resp = requests.post(f'{API_BASE}/run_ingest')
                st.json(resp.json())

    st.markdown('---')
    st.subheader('Synthetic datasets (demo)')
    synth_file = st.selectbox('Choose synthetic CSV', ['01_synthetic_data_low.csv', '02_synthetic_data_medium.csv'])
    if st.button('Ingest synthetic dataset'):
        with st.spinner(f'Ingesting {synth_file}...'):
            resp = requests.post(f'{API_BASE}/ingest_synthetic', params={'filename': synth_file})
            try:
                st.json(resp.json())
            except Exception:
                st.error('Failed to ingest synthetic dataset')

    if st.button('Run Decision Agent (on persisted resources)'):
        with st.spinner('Running decision agent...'):
            resp = requests.post(f'{API_BASE}/run_decision')
            try:
                st.json(resp.json())
            except Exception:
                st.error('Failed to run decision agent')

elif menu == 'Resources':
    st.header('Resources')
    try:
        resp = requests.get(f'{API_BASE}/resources')
        resources = resp.json().get('resources', [])
        for r in resources:
            with st.expander(f"{r.get('name')} (team: {r.get('team')})"):
                st.write('Skills:', r.get('skills'))
                st.write('Allocation:', r.get('allocation'))
    except Exception as e:
        st.error(str(e))

elif menu == 'Decisions':
    st.header('Decisions')
    try:
        resp = requests.get(f'{API_BASE}/decisions')
        decisions = resp.json().get('decisions', [])
        for d in decisions:
            st.write(f"#{d.get('id')} - {d.get('resource_name')} - {d.get('action')} - {d.get('reason')} - status={d.get('status')}")
            col1, col2 = st.columns(2)
            if col1.button('Accept', key=f"accept_{d.get('id')}"):
                requests.post(f"{API_BASE}/decisions/{d.get('id')}/update", json={'status': 'accepted'})
                st.experimental_rerun()
            if col2.button('Reject', key=f"reject_{d.get('id')}"):
                requests.post(f"{API_BASE}/decisions/{d.get('id')}/update", json={'status': 'rejected'})
                st.experimental_rerun()
    except Exception as e:
        st.error(str(e))
