﻿from sqlalchemy import create_engine, Column, Integer, String, Float, JSON, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from datetime import datetime

Base = declarative_base()

class Resource(Base):
    __tablename__ = 'resources'
    id = Column(Integer, primary_key=True)
    name = Column(String, index=True)
    team = Column(String, index=True)
    skills = Column(JSON)
    allocation = Column(Float)

class Decision(Base):
    __tablename__ = 'decisions'
    id = Column(Integer, primary_key=True)
    resource_id = Column(Integer, index=True)
    resource_name = Column(String, index=True)
    action = Column(String)
    reason = Column(String)
    status = Column(String, default='pending')
    created_at = Column(DateTime, default=datetime.utcnow)

class Job(Base):
    __tablename__ = 'jobs'
    id = Column(Integer, primary_key=True)
    job_type = Column(String, index=True)
    payload = Column(JSON)
    status = Column(String, default='pending')
    result = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)


def get_engine(sqlite_path: str | None = None):
    sqlite_path = sqlite_path or os.getenv('SQLITE_PATH', './data/resource_capacity.db')
    engine = create_engine(f'sqlite:///{sqlite_path}', connect_args={"check_same_thread": False})
    return engine

engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    os.makedirs(os.path.dirname(engine.url.database), exist_ok=True)
    Base.metadata.create_all(bind=engine)

# Helper utilities
def create_resource_from_dict(session, rd: dict):
    r = Resource(
        name=rd.get('name') or rd.get('resource') or 'unknown',
        team=rd.get('team'),
        skills=rd.get('skills') or [],
        allocation=float(rd.get('allocation') or 0)
    )
    session.add(r)
    session.flush()
    return r

def list_resources(session):
    rows = session.query(Resource).all()
    out = []
    for r in rows:
        out.append({
            'id': r.id,
            'name': r.name,
            'team': r.team,
            'skills': r.skills,
            'allocation': r.allocation
        })
    return out

def add_decision(session, resource_id: int | None, resource_name: str, action: str, reason: str):
    d = Decision(resource_id=resource_id, resource_name=resource_name, action=action, reason=reason, status='pending')
    session.add(d)
    session.flush()
    return d

def list_decisions(session):
    rows = session.query(Decision).order_by(Decision.created_at.desc()).all()
    out = []
    for d in rows:
        out.append({
            'id': d.id,
            'resource_id': d.resource_id,
            'resource_name': d.resource_name,
            'action': d.action,
            'reason': d.reason,
            'status': d.status,
            'created_at': d.created_at.isoformat() if d.created_at else None
        })
    return out

# Job helpers

def create_job(session, job_type: str, payload: dict):
    job = Job(job_type=job_type, payload=payload, status='pending')
    session.add(job)
    session.flush()
    return job

def list_jobs(session):
    rows = session.query(Job).order_by(Job.created_at.desc()).all()
    out = []
    for j in rows:
        out.append({
            'id': j.id,
            'job_type': j.job_type,
            'payload': j.payload,
            'status': j.status,
            'result': j.result,
            'created_at': j.created_at.isoformat() if j.created_at else None,
            'started_at': j.started_at.isoformat() if j.started_at else None,
            'finished_at': j.finished_at.isoformat() if j.finished_at else None,
        })
    return out

def get_job(session, job_id: int):
    j = session.query(Job).filter(Job.id == job_id).first()
    if not j:
        return None
    return {
        'id': j.id,
        'job_type': j.job_type,
        'payload': j.payload,
        'status': j.status,
        'result': j.result,
        'created_at': j.created_at.isoformat() if j.created_at else None,
        'started_at': j.started_at.isoformat() if j.started_at else None,
        'finished_at': j.finished_at.isoformat() if j.finished_at else None,
    }

def update_job_status(session, job_id: int, status: str, result: str | None = None, started_at=None, finished_at=None):
    j = session.query(Job).filter(Job.id == job_id).first()
    if not j:
        return None
    j.status = status
    if result is not None:
        j.result = result
    if started_at is not None:
        j.started_at = started_at
    if finished_at is not None:
        j.finished_at = finished_at
    session.flush()
    return j
