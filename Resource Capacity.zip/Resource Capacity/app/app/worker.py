# Simple background worker that polls the DB for pending jobs and executes them.
import time
import json
import traceback
from datetime import datetime

from .db import SessionLocal, Job, update_job_status
from .services import ingest_synthetic_file, run_decision_on_persisted

POLL_INTERVAL = 2.0


def _now_iso():
    return datetime.utcnow().isoformat()


def run_worker():
    print('[worker] starting worker loop...')
    while True:
        session = SessionLocal()
        try:
            # Find a pending job
            job = session.query(Job).filter(Job.status == 'pending').order_by(Job.created_at).with_for_update().first()
            if not job:
                session.close()
                time.sleep(POLL_INTERVAL)
                continue

            print(f"[worker] picked job id={job.id} type={job.job_type}")
            # mark started
            job.status = 'running'
            job.started_at = datetime.utcnow()
            session.commit()

            result = None
            try:
                payload = job.payload or {}
                if job.job_type == 'ingest_synthetic':
                    filename = payload.get('filename', '01_synthetic_data_low.csv')
                    out = ingest_synthetic_file(filename)
                    result = json.dumps(out)
                elif job.job_type == 'run_decision':
                    out = run_decision_on_persisted()
                    result = json.dumps(out)
                else:
                    result = json.dumps({'error': f'unknown job_type {job.job_type}'})
                    job.status = 'failed'

                if job.status != 'failed':
                    job.status = 'finished'
                job.result = result
                job.finished_at = datetime.utcnow()
                session.commit()
                print(f"[worker] finished job id={job.id} status={job.status}")
            except Exception as e:
                tb = traceback.format_exc()
                job.status = 'failed'
                job.result = json.dumps({'error': str(e), 'trace': tb})
                job.finished_at = datetime.utcnow()
                session.commit()
                print(f"[worker] job id={job.id} failed: {e}")
        except Exception as e:
            print('[worker] unexpected error:', e)
            try:
                session.rollback()
            except Exception:
                pass
            time.sleep(POLL_INTERVAL)
        finally:
            try:
                session.close()
            except Exception:
                pass


if __name__ == '__main__':
    run_worker()
