# ...existing code...
import os
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()
API_KEY = os.getenv('GENAI_API_KEY')
BASE_URL = os.getenv('GENAI_BASE_URL')
LLM_MODEL = os.getenv('GENAI_LLM_MODEL')

_custom_client = httpx.Client(verify=False)
llm = ChatOpenAI(base_url=BASE_URL, api_key=API_KEY, model=LLM_MODEL, http_client=_custom_client)

# Minimal multi-agent orchestrator: parser, validator, decision, communicator

def parse_documents(sample_text: str) -> dict:
    prompt = f"Extract resources from the following text into JSON records with fields: name, team, skills (list), allocation (0-1 float).\n\nText:\n{sample_text}"
    resp = llm.invoke(prompt)
    try:
        import json
        return json.loads(resp.content)
    except Exception:
        return {"error": resp.content}


def validate_resources(resources: list[dict]) -> list[dict]:
    # simple rule-based validation
    issues = []
    for r in resources:
        if 'allocation' in r and (r['allocation'] < 0 or r['allocation'] > 1):
            issues.append({'name': r.get('name'), 'issue': 'allocation_out_of_bounds'})
    return issues


def decide_rebalance(resources: list[dict]) -> list[dict]:
    # naive decision: if allocation > 0.9 suggest split; if <0.2 suggest reassign
    decisions = []
    for r in resources:
        if r.get('allocation', 0) > 0.9:
            decisions.append({'name': r.get('name'), 'action': 'reduce_allocation', 'reason': 'overallocated'})
        elif r.get('allocation', 0) < 0.2:
            decisions.append({'name': r.get('name'), 'action': 'increase_allocation_or_reassign', 'reason': 'underallocated'})
    return decisions


def communicate(decisions: list[dict]) -> str:
    if not decisions:
        return 'No actions recommended.'
    lines = ['Recommendations:']
    for d in decisions:
        lines.append(f"- {d['name']}: {d['action']} ({d['reason']})")
    return "\n".join(lines)

# ...existing code...
