# ...existing code...
import os
from ..references import ingestion_rag

def run_ingest(local_dir: str | None = None):
    # simple wrapper to call the reference ingestion pipeline
    if local_dir:
        ingestion_rag.LOCAL_FILES_DIR = local_dir
    ingestion_rag.run_ingestion_pipeline()

# ...existing code...
