﻿from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
import importlib
import importlib.util
from pathlib import Path
import pandas as pd
from collections import Counter

from .db import (
    init_db, SessionLocal, create_resource_from_dict, list_resources,
    add_decision, list_decisions, Decision, create_job, list_jobs, get_job, update_job_status
)
from .agents import parse_documents, validate_resources, decide_rebalance, communicate
from .services import ingest_synthetic_file, run_decision_on_persisted

app = FastAPI()
init_db()

class IngestPayload(BaseModel):
    text: str

# DB dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post('/ingest')
def ingest(payload: IngestPayload, db: Session = Depends(get_db)):
    parsed = parse_documents(payload.text)
    if isinstance(parsed, dict) and 'error' in parsed:
        raise HTTPException(status_code=500, detail=parsed['error'])
    resources = parsed if isinstance(parsed, list) else [parsed]
    issues = validate_resources(resources)
    decisions = decide_rebalance(resources)
    message = communicate(decisions)

    # persist parsed resources and decisions
    saved = []
    for r in resources:
        res = create_resource_from_dict(db, r)
        saved.append({'id': res.id, 'name': res.name})
    for d in decisions:
        resource_id = next((s['id'] for s in saved if s['name'] == d.get('name')), None)
        add_decision(db, resource_id, d.get('name'), d.get('action'), d.get('reason'))

    db.commit()
    return {'parsed': resources, 'issues': issues, 'decisions': decisions, 'message': message}

@app.get('/resources')
def resources_list(db: Session = Depends(get_db)):
    return {'resources': list_resources(db)}

@app.get('/decisions')
def decisions_list(db: Session = Depends(get_db)):
    return {'decisions': list_decisions(db)}

class DecisionUpdate(BaseModel):
    status: str

@app.post('/decisions/{decision_id}/update')
def update_decision(decision_id: int, payload: DecisionUpdate, db: Session = Depends(get_db)):
    dec = db.query(Decision).filter(Decision.id == decision_id).first()
    if not dec:
        raise HTTPException(status_code=404, detail='decision not found')
    dec.status = payload.status
    db.commit()
    return {'id': dec.id, 'status': dec.status}

# Robust dynamic loader for the reference ingestion module
ingestion_rag = None
__ingestion_load_error__ = None
try:
    pkg = importlib.import_module('app.references')
    ingestion_rag = getattr(pkg, 'ingestion_rag', None)
except Exception:
    try:
        workspace_root = Path(__file__).resolve().parents[2]
        candidate = workspace_root / 'references for code generation' / 'ingestion_rag.py'
        if candidate.exists():
            spec = importlib.util.spec_from_file_location('ingestion_rag', str(candidate))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            ingestion_rag = mod
        else:
            alt = Path(__file__).resolve().parents[1] / 'references' / '__init__.py'
            if alt.exists():
                spec = importlib.util.spec_from_file_location('app_references', str(alt))
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                ingestion_rag = getattr(mod, 'ingestion_rag', None)
    except Exception as e:
        __ingestion_load_error__ = e

@app.post('/run_ingest')
def run_ingest():
    if ingestion_rag is None:
        detail = str(__ingestion_load_error__) if __ingestion_load_error__ else 'ingestion module not loaded'
        raise HTTPException(status_code=500, detail=detail)
    try:
        ingestion_rag.run_ingestion_pipeline()
        return {'status': 'ok', 'message': 'ingestion finished (check storage_faiss)'}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Synthetic CSV ingestion endpoint (sync)
@app.post('/ingest_synthetic')
def ingest_synthetic(filename: str = '01_synthetic_data_low.csv', db: Session = Depends(get_db)):
    try:
        out = ingest_synthetic_file(filename)
        return out
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Job endpoints: enqueue and list
@app.post('/jobs/enqueue_ingest_synthetic')
def enqueue_ingest_synthetic(filename: str = '01_synthetic_data_low.csv', db: Session = Depends(get_db)):
    job = create_job(db, 'ingest_synthetic', {'filename': filename})
    db.commit()
    return {'job_id': job.id, 'status': job.status}

@app.post('/jobs/enqueue_run_decision')
def enqueue_run_decision(db: Session = Depends(get_db)):
    job = create_job(db, 'run_decision', {})
    db.commit()
    return {'job_id': job.id, 'status': job.status}

@app.get('/jobs')
def jobs_list(db: Session = Depends(get_db)):
    return {'jobs': list_jobs(db)}

@app.get('/jobs/{job_id}')
def jobs_get(job_id: int, db: Session = Depends(get_db)):
    j = get_job(db, job_id)
    if not j:
        raise HTTPException(status_code=404, detail='job not found')
    return j

# metrics endpoint
@app.get('/metrics')
def metrics(db: Session = Depends(get_db)):
    resources = list_resources(db)
    total = len(resources)
    avg_alloc = sum(r.get('allocation', 0) for r in resources) / (total or 1)
    skills = []
    team_alloc = {}
    for r in resources:
        for s in (r.get('skills') or []):
            skills.append(s)
        team = r.get('team') or 'Unknown'
        team_alloc.setdefault(team, []).append(r.get('allocation') or 0)
    skill_counts = dict(Counter(skills))
    team_summary = {t: {'count': len(vals), 'avg_allocation': sum(vals) / (len(vals) or 1)} for t, vals in team_alloc.items()}
    return {
        'total_resources': total,
        'avg_allocation': avg_alloc,
        'skill_counts': skill_counts,
        'team_summary': team_summary
    }

# run decision (sync)
@app.post('/run_decision')
def run_decision(db: Session = Depends(get_db)):
    return run_decision_on_persisted()

@app.get('/health')
def health():
    return {'status': 'ok'}
