from pathlib import Path
import pandas as pd
from .db import SessionLocal, create_resource_from_dict, add_decision, list_resources
from .agents import validate_resources, decide_rebalance


def ingest_synthetic_file(filename: str):
    workspace_root = Path(__file__).resolve().parents[2]
    fpath = workspace_root / filename
    if not fpath.exists():
        raise FileNotFoundError(f"file not found: {fpath}")

    df = pd.read_csv(fpath)
    resources = []
    for _, row in df.iterrows():
        skills_raw = row.get('Skills') if 'Skills' in row else ''
        skills = [s.strip() for s in str(skills_raw).split(',') if s.strip()]
        alloc_raw = None
        for col in ['Allocation_%', 'Allocation_%', 'Allocation', 'Allocation_ %', 'Allocation_% ']:
            if col in row:
                alloc_raw = row.get(col)
                break
        try:
            allocation = float(alloc_raw) / 100.0 if alloc_raw is not None else 0.0
        except Exception:
            allocation = 0.0
        rd = {
            'name': row.get('Name') or row.get('Resource_ID'),
            'team': row.get('Team'),
            'skills': skills,
            'allocation': allocation
        }
        resources.append(rd)

    db = SessionLocal()
    try:
        saved = []
        for r in resources:
            res = create_resource_from_dict(db, r)
            saved.append({'id': res.id, 'name': res.name})

        issues = validate_resources(resources)
        decisions = decide_rebalance(resources)

        persisted = []
        for d in decisions:
            resource_id = next((s['id'] for s in saved if s['name'] == d.get('name')), None)
            dec = add_decision(db, resource_id, d.get('name'), d.get('action'), d.get('reason'))
            persisted.append({'id': dec.id, 'resource_id': dec.resource_id, 'resource_name': dec.resource_name, 'action': dec.action, 'reason': dec.reason})

        db.commit()
        return {'saved': saved, 'issues': issues, 'decisions': persisted}
    finally:
        db.close()


def run_decision_on_persisted():
    db = SessionLocal()
    try:
        resources = list_resources(db)
        agent_input = []
        for r in resources:
            agent_input.append({
                'name': r.get('name'),
                'team': r.get('team'),
                'skills': r.get('skills'),
                'allocation': r.get('allocation')
            })
        issues = validate_resources(agent_input)
        decisions = decide_rebalance(agent_input)
        persisted = []
        for d in decisions:
            resource_id = next((s['id'] for s in resources if s['name'] == d.get('name')), None)
            dec = add_decision(db, resource_id, d.get('name'), d.get('action'), d.get('reason'))
            persisted.append({'id': dec.id, 'resource_id': dec.resource_id, 'resource_name': dec.resource_name, 'action': dec.action, 'reason': dec.reason})
        db.commit()
        return {'issues': issues, 'decisions': persisted}
    finally:
        db.close()
